-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Client :  127.0.0.1
-- Généré le :  Mar 14 Août 2018 à 18:53
-- Version du serveur :  5.7.14-log
-- Version de PHP :  7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `coa_symfony`
--

-- --------------------------------------------------------

--
-- Structure de la table `actor`
--

CREATE TABLE `actor` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL,
  `description` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movie_nbr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `actor`
--

INSERT INTO `actor` (`id`, `name`, `slug`, `create_at`, `description`, `image`, `movie_nbr`) VALUES
(1, 'Angela Mwandanda', 'angela-mwandanda', '2017-08-20 17:37:26', '', NULL, 0),
(2, 'Quincy Wandera', 'quincy-wandera', '2017-08-20 17:38:00', '', NULL, 0),
(3, 'Elle Ciru MBeria', 'elle-ciru-mberia', '2017-08-20 17:38:31', '', NULL, 0),
(4, 'Nouhoum Kone', 'nouhoum-kone', '2017-08-20 17:41:23', '', NULL, 0),
(5, 'Peter Kamu', 'peter-kamu', '2017-08-20 17:41:43', '', NULL, 0),
(6, 'Liz Solari', 'liz-solari', '2017-08-20 17:42:03', '', NULL, 0),
(7, 'Tomais de las Heras', 'tomais-de-las-heras', '2017-08-20 17:42:25', '', NULL, 0),
(8, 'Laetitia Reva', 'laetitia-reva', '2017-08-20 17:43:05', '', NULL, 0),
(9, 'Pierrick Le Pochat', 'pierrick-le-pochat', '2017-08-20 17:43:25', '', NULL, 0),
(10, 'Afazali Dewaele', 'afazali-dewaele', '2017-08-20 17:43:43', '', NULL, 2),
(11, 'Emma Stone', 'emma-stone', '2017-08-20 17:44:00', '', NULL, 0),
(12, 'Jessica Chastain', 'jessica-chastain', '2017-08-20 17:44:20', '', NULL, 0),
(13, 'Viola Davis', 'viola-davis', '2017-08-20 17:44:40', '', NULL, 0),
(14, 'Octavia Spencer', 'octavia-spencer', '2017-08-20 17:44:54', '', NULL, 0),
(15, 'Fouda Marie Noel', 'fouda-marie-noel', '2017-08-20 17:45:11', '', NULL, 0),
(16, 'Belibi', 'belibi', '2017-08-20 17:45:25', '', NULL, 0),
(17, 'Marie Mado', 'marie-mado', '2017-08-20 17:45:44', '', NULL, 0),
(18, 'Bikarata', 'bikarata', '2017-08-20 17:47:23', '', NULL, 1),
(19, 'Edouadoua', 'edouadoua', '2017-08-20 17:47:38', '', NULL, 0),
(20, 'Daniela Alvarado', 'daniela-alvarado', '2017-08-20 17:48:16', '', NULL, 1),
(21, 'Ricardo Alamo', 'ricardo-alamo', '2017-08-20 17:48:33', '', NULL, 0),
(22, 'Roxana Diaz', 'roxana-diaz', '2017-08-20 17:48:53', '', NULL, 0),
(23, 'Jonathan Montenegro', 'jonathan-montenegro', '2017-08-20 17:49:10', '', NULL, 0),
(24, 'Juan Carlos Alarcon', 'juan-carlos-alarcon', '2017-08-20 17:49:30', '', NULL, 0),
(25, 'Marialejandra Martin', 'marialejandra-martin', '2017-08-20 17:49:46', '', NULL, 0),
(26, 'Michelle Dede', 'michelle-dede', '2017-08-20 17:50:30', '', NULL, 0),
(27, 'Kwame Bonsu', 'kwame-bonsu', '2017-08-20 17:50:47', '', NULL, 0),
(28, 'Florence NDuta', 'florence-nduta', '2017-08-20 17:51:04', '', NULL, 0),
(29, 'Frank Kimani', 'frank-kimani', '2017-08-20 17:51:20', '', NULL, 0),
(30, 'Jamie Lee Curtis', 'jamie-lee-curtis', '2017-08-20 17:51:45', '', NULL, 0),
(31, 'Lindsay Lohan', 'lindsay-lohan', '2017-08-20 17:52:07', '', NULL, 0),
(32, 'Mark Harmon', 'mark-harmon', '2017-08-20 17:52:25', '', NULL, 0),
(33, 'Harold Gould', 'harold-gould', '2017-08-20 17:52:44', '', NULL, 0),
(34, 'Joshua Bingwa', 'joshua-bingwa', '2017-08-20 17:53:36', '', NULL, 0),
(35, 'Ruth Maingi', 'ruth-maingi', '2017-08-20 17:54:06', '', NULL, 0),
(36, 'Chris Kamau', 'chris-kamau', '2017-08-20 17:54:25', '', NULL, 0),
(37, 'Melissa Kiplagat', 'melissa-kiplagat', '2017-08-20 17:54:42', '', NULL, 0),
(38, 'Shaka Katabarwa', 'shaka-katabarwa', '2017-08-20 17:54:57', '', NULL, 0),
(39, 'Giovanna Antonelli', 'giovanna-antonelli', '2017-08-20 17:55:20', '', NULL, 0),
(40, 'Reynaldo Gianecchini', 'reynaldo-gianecchini', '2017-08-20 17:55:41', '', NULL, 0),
(41, 'Tais Araujo', 'tais-araujo', '2017-08-20 17:55:58', '', NULL, 0),
(42, 'Lima Duarte', 'lima-duarte', '2017-08-20 17:56:13', '', NULL, 0),
(43, 'Rosi Campos', 'rosi-campos', '2017-08-20 17:56:32', '', NULL, 0),
(44, 'Caio Blat', 'caio-blat', '2017-08-20 17:57:39', '', NULL, 0),
(45, 'Aline Morais', 'aline-morais', '2017-08-20 17:57:55', '', NULL, 0),
(46, 'Leonardo Bricio', 'leonardo-bricio', '2017-08-20 17:58:09', '', NULL, 0),
(47, 'Lucélia Santos', 'lucelia-santos', '2017-08-20 17:58:31', '', NULL, 0),
(48, 'Rubens Falco', 'rubens-falco', '2017-08-20 17:58:50', '', NULL, 0),
(49, 'Elaine Cristina', 'elaine-cristina', '2017-08-20 17:59:11', '', NULL, 0),
(50, 'Marcos Paulo', 'marcos-paulo', '2017-08-20 17:59:26', '', NULL, 0),
(51, 'Antonio Pompeo', 'antonio-pompeo', '2017-08-20 17:59:42', '', NULL, 0),
(52, 'Chica Xavier', 'chica-xavier', '2017-08-20 17:59:58', '', NULL, 0),
(53, 'Patricia Pillar', 'patricia-pillar', '2017-08-20 18:00:14', '', NULL, 0),
(54, 'Rachel True', 'rachel-true', '2017-08-20 18:00:40', '', NULL, 0),
(55, 'Telma Hopkins', 'telma-hopkins', '2017-08-20 18:00:58', '', NULL, 0),
(56, 'Valarie Pettiford', 'valarie-pettiford', '2017-08-20 18:01:18', '', NULL, 0),
(57, 'Essence Atkins', 'essence-atkins', '2017-08-20 18:01:35', '', NULL, 0),
(58, 'Chico Benymon', 'chico-benymon', '2017-08-20 18:01:53', '', NULL, 0),
(59, 'Alec Mapa', 'alec-mapa', '2017-08-20 18:02:13', '', NULL, 0),
(60, 'MC Lyte', 'mc-lyte', '2017-08-20 18:02:40', '', NULL, 0),
(61, 'Obba Babatundé', 'obba-babatunde', '2017-08-20 18:03:03', '', NULL, 0),
(62, 'Joey Lawrence', 'joey-lawrence', '2017-08-20 18:03:22', '', NULL, 0),
(63, 'Coby Bell', 'coby-bell', '2017-08-20 18:03:40', '', NULL, 0),
(64, 'Keith Robinson', 'keith-robinson', '2017-08-20 18:03:56', '', NULL, 0),
(65, 'Michelle Williams', 'michelle-williams', '2017-08-20 18:04:17', '', NULL, 0),
(66, 'Yvette Nicole Brown', 'yvette-nicole-brown', '2017-08-20 18:04:35', '', NULL, 0),
(67, 'Louis Gossett', 'louis-gossett', '2017-08-20 18:04:51', '', NULL, 0),
(68, 'Anika Noni Rose', 'anika-noni-rose', '2017-08-20 18:05:07', '', NULL, 0),
(69, 'Bruno Campos', 'bruno-campos', '2017-08-20 18:07:22', '', NULL, 0),
(70, 'Keith David plus', 'keith-david-plus', '2017-08-20 18:07:42', '', NULL, 0),
(71, 'Henri Castelli', 'henri-castelli', '2017-08-20 18:08:09', '', NULL, 0),
(72, 'Grazi Massafera', 'grazi-massafera', '2017-08-20 18:08:25', '', NULL, 0),
(73, 'Igor Rickli', 'igor-rickli', '2017-08-20 18:08:42', '', NULL, 0),
(74, 'César Troncoso', 'cesar-troncoso', '2017-08-20 18:08:58', '', NULL, 0),
(75, 'Jean Pierre Noher', 'jean-pierre-noher', '2017-08-20 18:09:25', '', NULL, 0),
(76, 'Moro Anghileri', 'moro-anghileri', '2017-08-20 18:09:53', '', NULL, 0),
(77, 'Roger Carel', 'roger-carel', '2017-08-20 18:10:12', '', NULL, 0),
(78, 'Jacques Frantz', 'jacques-frantz', '2017-08-20 18:11:00', '', NULL, 0),
(79, 'Juliana Paes', 'juliana-paes', '2017-08-20 18:11:41', '', NULL, 0),
(80, 'Rodrigo Lombardi', 'rodrigo-lombardi', '2017-08-20 18:11:58', '', NULL, 0),
(81, 'Tânia Khalil', 'tania-khalil', '2017-08-20 18:12:15', '', NULL, 0),
(82, 'Marcio Garcia', 'marcio-garcia', '2017-08-20 18:13:56', '', NULL, 0),
(83, 'Tony Ramos', 'tony-ramos', '2017-08-20 18:14:20', '', NULL, 0),
(84, 'Laura Cardoso', 'laura-cardoso', '2017-08-20 18:14:56', '', NULL, 0),
(85, 'Christiane Torloni', 'christiane-torloni', '2017-08-20 18:15:12', '', NULL, 0),
(86, 'Débora Bloch', 'debora-bloch', '2017-08-20 18:15:51', '', NULL, 0),
(87, 'Stéphane (Flame) Zabavy', 'stephane-flame-zabavy', '2017-08-20 18:16:24', '', NULL, 0),
(88, 'Bienvenu Neba', 'bienvenu-neba', '2017-08-20 18:17:10', '', NULL, 0),
(89, 'Ismael Radji', 'ismael-radji', '2017-08-20 18:17:40', '', NULL, 0),
(90, 'Esther Uha', 'esther-uha', '2017-08-20 18:18:07', '', NULL, 0),
(91, 'Maximin Adje', 'maximin-adje', '2017-08-20 18:18:37', '', NULL, 0),
(92, 'Guy Kalou', 'guy-kalou', '2017-08-20 18:19:16', '', NULL, 0),
(93, 'Abdoul Karim', 'abdoul-karim', '2017-08-20 18:19:36', '', NULL, 3),
(94, 'Nina Kramoko', 'nina-kramoko', '2017-08-20 18:20:01', '', NULL, 0),
(95, 'Marie-Louise Asseu', 'marie-louise-asseu', '2017-08-20 18:20:21', '', NULL, 0),
(96, 'Ange Bia', 'ange-bia', '2017-08-20 18:21:01', '', NULL, 0),
(97, 'Désiré Begro', 'desire-begro', '2017-08-20 18:21:17', '', NULL, 0),
(98, 'Lamine Cissé', 'lamine-cisse', '2017-08-20 18:21:33', '', NULL, 0),
(99, 'Evelyne Ily', 'evelyne-ily', '2017-08-20 18:22:04', '', NULL, 0),
(100, 'Joséphine Tagro', 'josephine-tagro', '2017-08-20 18:22:20', '', NULL, 0),
(101, 'Véronique Beya Mputu', 'veronique-beya-mputu', '2017-08-20 18:22:42', '', NULL, 0),
(102, 'Papi Mpaka', 'papi-mpaka', '2017-08-20 18:23:00', '', NULL, 0),
(103, 'Gaetan Claudias', 'gaetan-claudias', '2017-08-20 18:23:16', '', NULL, 0),
(104, 'Jennifer Lopez', 'jennifer-lopez', '2017-08-20 18:23:33', '', NULL, 0),
(105, 'Alex O\'Loughlin', 'alex-oloughlin', '2017-08-20 18:23:51', '', NULL, 0),
(106, 'Michaela Watkins', 'michaela-watkins', '2017-08-20 18:24:05', '', NULL, 0),
(107, 'Juliana Margulies', 'juliana-margulies', '2017-08-20 18:24:30', '', NULL, 0),
(108, 'Matt Gzuchry', 'matt-gzuchry', '2017-08-20 18:24:48', '', NULL, 0),
(109, 'Archie Panjabi', 'archie-panjabi', '2017-08-20 18:25:12', '', NULL, 0),
(110, 'Danna Garcia', 'danna-garcia', '2017-08-20 18:25:39', '', NULL, 0),
(111, 'José Angel Llamas', 'jose-angel-llamas', '2017-08-20 18:25:58', '', NULL, 0),
(112, 'Saby Kamalich', 'saby-kamalich', '2017-08-20 18:26:17', '', NULL, 0),
(113, 'Carlos Torres Torrija', 'carlos-torres-torrija', '2017-08-20 18:26:33', '', NULL, 0),
(114, 'Ximena Rubio', 'ximena-rubio', '2017-08-20 18:26:50', '', NULL, 0),
(115, 'Ana Ciocchetti', 'ana-ciocchetti', '2017-08-20 18:27:37', '', NULL, 0),
(116, 'Carlos De La Mota', 'carlos-de-la-mota', '2017-08-20 18:27:54', '', NULL, 0),
(117, 'Marcos Palmeira', 'marcos-palmeira', '2017-08-20 18:28:11', '', NULL, 0),
(118, 'Camila Pitanga', 'camila-pitanga', '2017-08-20 18:28:30', '', NULL, 0),
(119, 'Paola Oliveira', 'paola-oliveira', '2017-08-20 18:28:45', '', NULL, 0),
(120, 'Carmo Dalla Vecchia', 'carmo-dalla-vecchia', '2017-08-20 18:29:06', '', NULL, 1),
(121, 'Mariana Ximenes', 'mariana-ximenes', '2017-08-20 18:29:30', '', NULL, 0),
(122, 'Carolina Dieckmann', 'carolina-dieckmann', '2017-08-20 18:30:39', '', NULL, 0),
(123, 'Wasna Ahmed', 'wasna-ahmed', '2017-08-20 18:31:18', '', NULL, 0),
(124, 'Pankay Singh Tiwari', 'pankay-singh-tiwari', '2017-08-20 18:31:40', '', NULL, 0),
(125, 'Vibha Anand', 'vibha-anand', '2017-08-20 18:31:56', '', NULL, 0),
(126, 'Amar Thakur', 'amar-thakur', '2017-08-20 18:32:43', '', NULL, 0),
(127, 'Rupa Divethia', 'rupa-divethia', '2017-08-20 18:32:58', '', NULL, 0),
(128, 'Falguni Desai', 'falguni-desai', '2017-08-20 18:33:20', '', NULL, 0),
(129, 'Jiten Lalwari', 'jiten-lalwari', '2017-08-20 18:33:36', '', NULL, 0),
(130, 'Lilia Cabral', 'lilia-cabral', '2017-08-20 18:34:45', '', NULL, 0),
(131, 'Suzana Vieira', 'suzana-vieira', '2017-08-20 18:35:05', '', NULL, 0),
(132, 'Renata Sorrah', 'renata-sorrah', '2017-08-20 18:35:46', '', NULL, 0),
(133, 'Eduardo Moscovis', 'eduardo-moscovis', '2017-08-20 18:36:06', '', NULL, 0),
(134, 'Marcello Antony', 'marcello-antony', '2017-08-20 18:36:30', '', NULL, 0),
(135, 'Claudia Rodrigues', 'claudia-rodrigues', '2017-08-20 18:37:08', '', NULL, 0),
(136, 'Dira Paes', 'dira-paes', '2017-08-20 18:37:25', '', NULL, 0),
(137, 'Sergio Loroza', 'sergio-loroza', '2017-08-20 18:37:41', '', NULL, 0),
(138, 'Claudio Mello', 'claudio-mello', '2017-08-20 18:38:19', '', NULL, 0),
(139, 'José Mayer', 'jose-mayer', '2017-08-20 18:38:38', '', NULL, 0),
(140, 'Alinne Moraes', 'alinne-moraes', '2017-08-20 18:39:30', '', NULL, 0),
(141, 'Thiago Lacerda', 'thiago-lacerda', '2017-08-20 18:40:12', '', NULL, 0),
(142, 'Daniel Dae Kim', 'daniel-dae-kim', '2017-08-20 18:40:53', '', NULL, 1),
(143, 'Grace Park', 'grace-park', '2017-08-20 18:41:16', '', NULL, 0),
(144, 'Scott Caan', 'scott-caan', '2017-08-20 18:41:33', '', NULL, 0),
(145, 'Teilor Grubbs', 'teilor-grubbs', '2017-08-20 18:41:54', '', NULL, 0),
(146, 'Chris O\'Donnell', 'chris-odonnell', '2017-08-20 18:42:14', '', NULL, 0),
(147, 'LL Cool J', 'll-cool-j', '2017-08-20 18:42:32', '', NULL, 0),
(148, 'Linda Hunt', 'linda-hunt', '2017-08-20 18:42:50', '', NULL, 0),
(149, 'Daniela Ruah', 'daniela-ruah', '2017-08-20 18:43:10', '', NULL, 0),
(150, 'Barrett Foa', 'barrett-foa', '2017-08-20 18:43:32', '', NULL, 2),
(151, 'Irene Cruz', 'irene-cruz', '2017-08-20 18:43:49', '', NULL, 0),
(152, 'Rogério Samora', 'rogerio-samora', '2017-08-20 18:44:13', '', NULL, 0),
(153, 'Mehmet Aslantug', 'mehmet-aslantug', '2017-08-20 18:44:39', '', NULL, 0),
(154, 'Caner Cindoruk', 'caner-cindoruk', '2017-08-20 18:44:57', '', NULL, 0),
(155, 'Paulo Betti', 'paulo-betti', '2017-08-20 18:57:15', '', NULL, 0),
(156, 'Nicette Bruno', 'nicette-bruno', '2017-08-20 18:57:36', '', NULL, 0),
(157, 'Stephany Brito', 'stephany-brito', '2017-08-20 18:58:01', '', NULL, 0),
(158, 'Maria Eduarda', 'maria-eduarda', '2017-08-20 18:58:26', '', NULL, 0),
(159, 'Malu Valle', 'malu-valle', '2017-08-20 18:58:52', '', NULL, 0),
(160, 'Julia Almeida', 'julia-almeida', '2017-08-20 18:59:15', '', NULL, 0),
(161, 'Raymond Sargeant', 'raymond-sargeant', '2017-08-20 18:59:41', '', NULL, 0),
(162, 'Johnny Barbuzano', 'johnny-barbuzano', '2017-08-20 19:00:01', '', NULL, 0),
(163, 'Krijay Govender', 'krijay-govender', '2017-08-20 19:00:32', '', NULL, 0),
(164, 'Sthembiso Mathenjwa', 'sthembiso-mathenjwa', '2017-08-20 19:00:51', '', NULL, 0),
(165, 'Shona Ferguson', 'shona-ferguson', '2017-08-20 19:01:14', '', NULL, 0),
(166, 'Tumisho Masha', 'tumisho-masha', '2017-08-20 19:01:32', '', NULL, 0),
(167, 'Connie Ferguson', 'connie-ferguson', '2017-08-20 19:01:52', '', NULL, 0),
(168, 'Gail Nkoane', 'gail-nkoane', '2017-08-20 19:02:16', '', NULL, 0),
(169, 'Ian Roberts', 'ian-roberts', '2017-08-20 19:02:49', '', NULL, 0),
(170, 'Nathaniel Ramabulana', 'nathaniel-ramabulana', '2017-08-20 19:03:29', '', NULL, 0),
(171, 'Albert Brooks', 'albert-brooks', '2017-08-20 19:03:53', '', NULL, 0),
(172, 'Ellen DeGeneres', 'ellen-degeneres', '2017-08-20 19:04:16', '', NULL, 0),
(173, 'Alexander Gould', 'alexander-gould', '2017-08-20 19:04:45', '', NULL, 0),
(174, 'Caio Castro', 'caio-castro', '2017-08-20 19:05:54', '', NULL, 0),
(175, 'Sophie Charlotte', 'sophie-charlotte', '2017-08-20 19:06:13', '', NULL, 0),
(176, 'Malvino Salvador', 'malvino-salvador', '2017-08-20 19:06:30', '', NULL, 0),
(177, 'Murilo Rosa', 'murilo-rosa', '2017-08-20 19:06:53', '', NULL, 0),
(178, 'Cleo Pires', 'cleo-pires', '2017-08-20 19:07:42', '', NULL, 0),
(179, 'Milena Toscano', 'milena-toscano', '2017-08-20 19:08:55', '', NULL, 0),
(180, 'Raphael Viana', 'raphael-viana', '2017-08-20 19:09:55', '', NULL, 0),
(181, 'Thiago Fragoso', 'thiago-fragoso', '2017-08-20 19:10:26', '', NULL, 0),
(182, 'Regina Duarte', 'regina-duarte', '2017-08-20 19:10:53', '', NULL, 0),
(183, 'Edson Celulari', 'edson-celulari', '2017-08-20 19:11:48', '', NULL, 0),
(184, 'Anténio Fagundes', 'antenio-fagundes', '2017-08-20 19:12:19', '', NULL, 0),
(185, 'Gabriel Braga Nunes', 'gabriel-braga-nunes', '2017-08-20 19:12:39', '', NULL, 1),
(186, 'Dalton Vigh', 'dalton-vigh', '2017-08-20 19:14:05', '', NULL, 1),
(187, 'Marjorie Estiano', 'marjorie-estiano', '2017-08-20 19:14:25', '', NULL, 0),
(188, 'Susana Vieira', 'susana-vieira', '2017-08-20 19:14:58', '', NULL, 0),
(189, 'Aline Moraes', 'aline-moraes', '2017-08-20 19:15:26', '', NULL, 0),
(190, 'Francisco Cuoco', 'francisco-cuoco', '2017-08-20 19:15:46', '', NULL, 1),
(191, 'Herson Capri', 'herson-capri', '2017-08-20 19:16:28', '', NULL, 1),
(192, 'Lazaro Ramos', 'lazaro-ramos', '2017-08-20 19:17:33', '', NULL, 0),
(193, 'Gloria Pires', 'gloria-pires', '2017-08-20 19:18:24', '', NULL, 0),
(194, 'Alessandra Negrini', 'alessandra-negrini', '2017-08-20 19:18:51', '', NULL, 1),
(195, 'Debora Falabella', 'debora-falabella', '2017-08-20 19:19:58', '', NULL, 0),
(196, 'Adriana Esteves', 'adriana-esteves', '2017-08-20 19:20:27', '', NULL, 0),
(197, 'Nathalia Dill', 'nathalia-dill', '2017-08-20 19:20:48', '', NULL, 0),
(198, 'Marcello Novaes', 'marcello-novaes', '2017-08-20 19:21:12', '', NULL, 0),
(199, 'Eliane Giardini', 'eliane-giardini', '2017-08-20 19:21:30', '', NULL, 0),
(200, 'Marcos Caruso', 'marcos-caruso', '2017-08-20 19:21:46', '', NULL, 0),
(201, 'Ange Keffa', 'ange-keffa', '2017-08-20 19:22:25', '', NULL, 0),
(202, 'Omega David', 'omega-david', '2017-08-20 19:22:52', '', NULL, 0),
(203, 'Djimi Danger', 'djimi-danger', '2017-08-20 19:23:11', '', NULL, 0),
(204, 'Juca de Oliveira', 'juca-de-oliveira', '2017-08-20 19:24:24', '', NULL, 0),
(205, 'Reginaldo Faria', 'reginaldo-faria', '2017-08-20 19:25:06', '', NULL, 0),
(206, 'Vera Fischer', 'vera-fischer', '2017-08-20 19:25:25', '', NULL, 0),
(207, 'Daniela Escobar', 'daniela-escobar', '2017-08-20 19:25:46', '', NULL, 0),
(208, 'Antonio Calloni', 'antonio-calloni', '2017-08-20 19:26:08', '', NULL, 0),
(209, 'Kristin Kreuk', 'kristin-kreuk', '2017-08-20 19:27:11', '', NULL, 0),
(210, 'Jay Ryan (III)', 'jay-ryan-iii', '2017-08-20 19:27:28', '', NULL, 0),
(211, 'Austin Basis', 'austin-basis', '2017-08-20 19:27:55', '', NULL, 0),
(212, 'Max Brown', 'max-brown', '2017-08-20 19:28:22', '', NULL, 0),
(213, 'Nina Lisandrello', 'nina-lisandrello', '2017-08-20 19:28:51', '', NULL, 0),
(214, 'Brian J. White', 'brian-j-white', '2017-08-20 19:29:15', '', NULL, 0),
(215, 'Halle Bery', 'halle-bery', '2017-08-20 19:29:37', '', NULL, 0),
(216, 'Goran Visnjic', 'goran-visnjic', '2017-08-20 19:29:58', '', NULL, 0),
(217, 'Pierce Gagnon', 'pierce-gagnon', '2017-08-20 19:30:27', '', NULL, 0),
(218, 'Camryn Manheim', 'camryn-manheim', '2017-08-20 19:30:47', '', NULL, 0),
(219, 'Grace Gummer', 'grace-gummer', '2017-08-20 19:31:22', '', NULL, 0),
(220, 'Anna Wood', 'anna-wood', '2017-08-20 19:31:51', '', NULL, 0),
(221, 'Cam Gigandet', 'cam-gigandet', '2017-08-20 19:32:12', '', NULL, 1),
(222, 'Shawn Hatosy', 'shawn-hatosy', '2017-08-20 19:32:31', '', NULL, 0),
(223, 'Georgina Haig', 'georgina-haig', '2017-08-20 19:33:00', '', NULL, 0),
(224, 'Kim Wayans', 'kim-wayans', '2017-08-20 19:33:18', '', NULL, 0),
(225, 'Adam Rodriguez', 'adam-rodriguez', '2017-08-20 19:33:35', '', NULL, 0),
(226, 'Adelaide Kane', 'adelaide-kane', '2017-08-20 19:34:15', '', NULL, 0),
(227, 'Torrance Coombs', 'torrance-coombs', '2017-08-20 19:34:37', '', NULL, 0),
(228, 'Toby Regbo', 'toby-regbo', '2017-08-20 19:34:57', '', NULL, 0),
(229, 'Caitlin Stasey', 'caitlin-stasey', '2017-08-20 19:35:14', '', NULL, 0),
(230, 'Aimee Teegarden', 'aimee-teegarden', '2017-08-20 19:36:00', '', NULL, 0),
(231, 'Matt Lanter', 'matt-lanter', '2017-08-20 19:36:17', '', NULL, 0),
(232, 'Malese Jow', 'malese-jow', '2017-08-20 19:36:34', '', NULL, 0),
(233, 'Grey Damon', 'grey-damon', '2017-08-20 19:36:52', '', NULL, 0),
(234, 'Natalie Hall', 'natalie-hall', '2017-08-20 19:37:12', '', NULL, 0),
(235, 'Greg Finley', 'greg-finley', '2017-08-20 19:37:27', '', NULL, 0),
(236, 'Johnathon Schaech', 'johnathon-schaech', '2017-08-20 19:37:51', '', NULL, 0),
(237, 'William Petersen', 'william-petersen', '2017-08-20 19:38:12', '', NULL, 0),
(238, 'Mark Helgenberger', 'mark-helgenberger', '2017-08-20 19:38:33', '', NULL, 0),
(239, 'Gary Dourdan', 'gary-dourdan', '2017-08-20 19:39:09', '', NULL, 0),
(240, 'George Eads', 'george-eads', '2017-08-20 19:39:36', '', NULL, 0),
(241, 'Jorja Fox', 'jorja-fox', '2017-08-20 19:39:52', '', NULL, 0),
(242, 'Eric Szmanda', 'eric-szmanda', '2017-08-20 19:40:28', '', NULL, 0),
(243, 'Robert David Hall', 'robert-david-hall', '2017-08-20 19:40:44', '', NULL, 0),
(244, 'Paul Guilfoyle', 'paul-guilfoyle', '2017-08-20 19:41:01', '', NULL, 0),
(245, 'Marc Barbé', 'marc-barbe', '2017-08-20 19:41:23', '', NULL, 0),
(246, 'Mytri Attal', 'mytri-attal', '2017-08-20 19:41:43', '', NULL, 0),
(247, 'Anne Coesens', 'anne-coesens', '2017-08-20 19:42:03', '', NULL, 0),
(248, 'Jean-François Stévenin', 'jean-francois-stevenin', '2017-08-20 19:42:36', '', NULL, 0),
(249, 'Gary Sinise', 'gary-sinise', '2017-08-20 19:42:58', '', NULL, 0),
(250, 'Melina Kanakaredes', 'melina-kanakaredes', '2017-08-20 19:43:15', '', NULL, 0),
(251, 'Carmine Giovinazzo', 'carmine-giovinazzo', '2017-08-20 19:43:34', '', NULL, 0),
(252, 'Hill Harper', 'hill-harper', '2017-08-20 19:43:50', '', NULL, 0),
(253, 'Eddie Cahill', 'eddie-cahill', '2017-08-20 19:44:05', '', NULL, 1),
(254, 'Anna Belknap', 'anna-belknap', '2017-08-20 19:44:23', '', NULL, 0),
(255, 'Vanessa Verlito', 'vanessa-verlito', '2017-08-20 19:44:42', '', NULL, 0),
(256, 'George Ohawa', 'george-ohawa', '2017-08-20 19:45:03', '', NULL, 0),
(257, 'Mary Gacheri', 'mary-gacheri', '2017-08-20 19:45:22', '', NULL, 0),
(258, 'Mkamzee Mwatela', 'mkamzee-mwatela', '2017-08-20 19:45:42', '', NULL, 0),
(259, 'Mumbi Maina', 'mumbi-maina', '2017-08-20 19:45:58', '', NULL, 0),
(260, 'Brenda Wairimu', 'brenda-wairimu', '2017-08-20 19:46:15', '', NULL, 0),
(261, 'Kevin Samwel', 'kevin-samwel', '2017-08-20 19:46:32', '', NULL, 0),
(262, 'Daniel Peters', 'daniel-peters', '2017-08-20 19:46:56', '', NULL, 0),
(263, 'Nanda Costa', 'nanda-costa', '2017-08-20 19:48:55', '', NULL, 0),
(264, 'Claudia Raia', 'claudia-raia', '2017-08-20 19:50:24', '', NULL, 0),
(265, 'Totia Meireles', 'totia-meireles', '2017-08-20 19:50:51', '', NULL, 0),
(266, 'Lesliana Pereira', 'lesliana-pereira', '2017-08-20 19:51:13', '', NULL, 0),
(267, 'Ana Santos', 'ana-santos', '2017-08-20 19:51:31', '', NULL, 0),
(268, 'Erica Chissapa', 'erica-chissapa', '2017-08-20 19:52:11', '', NULL, 0),
(269, 'Miguel Hurst', 'miguel-hurst', '2017-08-20 19:53:35', '', NULL, 0),
(270, 'Zahra Kassam', 'zahra-kassam', '2017-08-20 19:54:08', '', NULL, 0),
(271, 'Kevin Ndege', 'kevin-ndege', '2017-08-20 19:54:25', '', NULL, 0),
(272, 'Anne Katamanda', 'anne-katamanda', '2017-08-20 19:55:07', '', NULL, 0),
(273, 'Chanda Nonde', 'chanda-nonde', '2017-08-20 19:55:35', '', NULL, 0),
(274, 'Martha B Siafwa', 'martha-b-siafwa', '2017-08-20 19:56:23', '', NULL, 0),
(275, 'Derby Kachasu', 'derby-kachasu', '2017-08-20 19:56:47', '', NULL, 0),
(276, 'Linda Chimese', 'linda-chimese', '2017-08-20 19:57:33', '', NULL, 0),
(277, 'Nicholas Raymond Banda', 'nicholas-raymond-banda', '2017-08-20 20:00:45', '', NULL, 0),
(278, 'Uche Nwadili', 'uche-nwadili', '2017-08-20 20:01:28', '', NULL, 0),
(279, 'Ngozi Nwaneto', 'ngozi-nwaneto', '2017-08-20 20:02:17', '', NULL, 0),
(280, 'Nonso Odogwu', 'nonso-odogwu', '2017-08-20 20:02:55', '', NULL, 0),
(281, 'Frances Okeke', 'frances-okeke', '2017-08-20 20:03:34', '', NULL, 0),
(282, 'Isis Valverde', 'isis-valverde', '2017-08-20 20:04:19', '', NULL, 0),
(283, 'Camila Morgado', 'camila-morgado', '2017-08-21 00:20:20', '', NULL, 0),
(284, 'Jeremy Renner', 'jeremy-renner', '2017-08-21 00:21:05', '', NULL, 0),
(285, 'Edward Norton', 'edward-norton', '2017-08-21 00:21:26', '', NULL, 0),
(286, 'Rachel Weisz', 'rachel-weisz', '2017-08-21 00:21:50', '', NULL, 0),
(287, 'Dakota Fanning', 'dakota-fanning', '2017-08-21 00:22:11', '', NULL, 0),
(288, 'Teri Hatcher', 'teri-hatcher', '2017-08-21 00:22:34', '', NULL, 0),
(289, 'John Hodgman', 'john-hodgman', '2017-08-21 00:22:52', '', NULL, 0),
(290, 'Julia Roberts', 'julia-roberts', '2017-08-21 00:23:16', '', NULL, 0),
(291, 'Clive Owen', 'clive-owen', '2017-08-21 00:23:36', '', NULL, 0),
(292, 'Tom Wilkinson', 'tom-wilkinson', '2017-08-21 00:23:55', '', NULL, 0),
(293, 'Paul Giamatti', 'paul-giamatti', '2017-08-21 00:24:20', '', NULL, 0),
(294, 'Johnny Depp', 'johnny-depp', '2017-08-21 00:24:37', '', NULL, 0),
(295, 'Christian Bale', 'christian-bale', '2017-08-21 00:24:55', '', NULL, 0),
(296, 'Marion Cotillard', 'marion-cotillard', '2017-08-21 00:25:17', '', NULL, 0),
(297, 'Matthew Macfadyen', 'matthew-macfadyen', '2017-08-21 00:25:33', '', NULL, 0),
(298, 'Cate Blanchett', 'cate-blanchett', '2017-08-21 00:25:51', '', NULL, 0),
(299, 'Jim Sturgess', 'jim-sturgess', '2017-08-21 00:26:09', '', NULL, 0),
(300, 'Anne Hathaway', 'anne-hathaway', '2017-08-21 00:26:31', '', NULL, 0),
(301, 'Rafe Spall', 'rafe-spall', '2017-08-21 00:27:11', '', NULL, 0),
(302, 'Romola Garai', 'romola-garai', '2017-08-21 00:27:29', '', NULL, 0),
(303, 'Natalia Oreiro', 'natalia-oreiro', '2017-08-21 00:27:44', '', NULL, 0),
(304, 'Facundo Arana', 'facundo-arana', '2017-08-21 00:28:03', '', NULL, 0),
(305, 'Carla Peterson', 'carla-peterson', '2017-08-21 00:28:22', '', NULL, 0),
(306, 'Carlos Belloso', 'carlos-belloso', '2017-08-21 00:28:44', '', NULL, 0),
(307, 'Alna Ndakissa', 'alna-ndakissa', '2017-08-21 00:29:00', '', NULL, 0),
(308, 'Régis Massimba', 'regis-massimba', '2017-08-21 00:29:16', '', NULL, 0),
(309, 'Monique Edzang', 'monique-edzang', '2017-08-21 00:31:27', '', NULL, 0),
(310, 'Luciano Castro', 'luciano-castro', '2017-08-21 00:32:08', '', NULL, 0),
(311, 'Muriel Santa Ana', 'muriel-santa-ana', '2017-08-21 00:32:31', '', NULL, 0),
(312, 'Sandra Ballesteros', 'sandra-ballesteros', '2017-08-21 00:32:47', '', NULL, 0),
(313, 'Vin Diesel', 'vin-diesel', '2017-08-21 00:33:12', '', NULL, 0),
(314, 'Paul Walker', 'paul-walker', '2017-08-21 00:33:29', '', NULL, 0),
(315, 'Dwayne Johnson', 'dwayne-johnson', '2017-08-21 00:33:49', '', NULL, 0),
(316, 'Joaquim de Almeida', 'joaquim-de-almeida', '2017-08-21 00:34:06', '', NULL, 0),
(317, 'Brad Pitt', 'brad-pitt', '2017-08-21 00:34:21', '', NULL, 0),
(318, 'Mélanie Laurent', 'melanie-laurent', '2017-08-21 00:34:43', '', NULL, 0),
(319, 'Christoph Waltz', 'christoph-waltz', '2017-08-21 00:35:02', '', NULL, 0),
(320, 'Michael Fassbender', 'michael-fassbender', '2017-08-21 00:35:20', '', NULL, 0),
(321, 'Tom Hanks', 'tom-hanks', '2017-08-21 00:35:41', '', NULL, 0),
(322, 'Cédric the Entetainer', 'cedric-the-entetainer', '2017-08-21 00:36:26', '', NULL, 0),
(323, 'Bryan Cranson', 'bryan-cranson', '2017-08-21 00:36:43', '', NULL, 0),
(324, 'Vivian Effo', 'vivian-effo', '2017-08-21 00:44:53', '', NULL, 0),
(325, 'Andre Claude Sea', 'andre-claude-sea', '2017-08-21 00:45:18', '', NULL, 0),
(326, 'Mai la bombe', 'mai-la-bombe', '2017-08-21 00:45:34', '', NULL, 0),
(327, 'Karim Hamzaoui', 'karim-hamzaoui', '2017-08-21 00:45:56', '', NULL, 0),
(328, 'Zakaria Ramadane', 'zakaria-ramadane', '2017-08-21 00:46:11', '', NULL, 0),
(329, 'Mouni Bouallam', 'mouni-bouallam', '2017-08-21 00:47:20', '', NULL, 0),
(330, 'Rania Serrouti', 'rania-serrouti', '2017-08-21 00:47:39', '', NULL, 0),
(331, 'Alfred Wanjau', 'alfred-wanjau', '2017-08-21 00:48:04', '', NULL, 0),
(332, 'Nduta Mbuthia', 'nduta-mbuthia', '2017-08-21 00:48:41', '', NULL, 0),
(333, 'Peter Kawa', 'peter-kawa', '2017-08-21 00:48:57', '', NULL, 0),
(334, 'Arabron Nyneque', 'arabron-nyneque', '2017-08-21 00:49:17', '', NULL, 0),
(335, 'Diogo Infante', 'diogo-infante', '2017-08-21 00:55:36', '', NULL, 0),
(336, 'Carlos Vieira', 'carlos-vieira', '2017-08-21 00:55:57', '', NULL, 0),
(337, 'Teresa Taveres', 'teresa-taveres', '2017-08-21 00:56:16', '', NULL, 0),
(338, 'Jean Gustave Conombo', 'jean-gustave-conombo', '2017-08-21 00:56:33', '', NULL, 0),
(339, 'Koné Boubacar', 'kone-boubacar', '2017-08-21 00:56:50', '', NULL, 0),
(340, 'Ouédraogo Valentin', 'ouedraogo-valentin', '2017-08-21 00:57:05', '', NULL, 0),
(341, 'Sawadogo Mahamadi', 'sawadogo-mahamadi', '2017-08-21 00:57:23', '', NULL, 0),
(342, 'Maïmouna Dembelé', 'maimouna-dembele', '2017-08-21 00:57:45', '', NULL, 0),
(343, 'Valentin Ouedraogo', 'valentin-ouedraogo', '2017-08-21 00:58:05', '', NULL, 0),
(344, 'Zenabou Rouambu', 'zenabou-rouambu', '2017-08-21 00:58:24', '', NULL, 0),
(345, 'Gervais Nombre', 'gervais-nombre', '2017-08-21 00:58:51', '', NULL, 0),
(346, 'Isabelle Béké', 'isabelle-beke', '2017-08-21 00:59:18', '', NULL, 0),
(347, 'Ibo laurent', 'ibo-laurent', '2017-08-21 00:59:39', '', NULL, 0),
(348, 'Romain Blanchet', 'romain-blanchet', '2017-08-21 00:59:54', '', NULL, 0),
(349, 'Audrey Hoareau', 'audrey-hoareau', '2017-08-21 01:00:13', '', NULL, 0),
(350, 'Clélie Lussart', 'clelie-lussart', '2017-08-21 01:00:45', '', NULL, 0),
(351, 'Christopher Ludovic Raboude', 'christopher-ludovic-raboude', '2017-08-21 01:01:01', '', NULL, 0),
(352, 'Bill Soupaya', 'bill-soupaya', '2017-08-21 01:01:18', '', NULL, 0),
(353, 'Nalini Aubeeluck', 'nalini-aubeeluck', '2017-08-21 01:01:35', '', NULL, 0),
(354, 'Ambereen Korimdun', 'ambereen-korimdun', '2017-08-21 01:01:53', '', NULL, 0),
(355, 'Christophe St Lambert', 'christophe-st-lambert', '2017-08-21 01:02:09', '', NULL, 0),
(356, 'Aurélie Calou', 'aurelie-calou', '2017-08-21 01:02:29', '', NULL, 0),
(357, 'Hans Aubeeluck', 'hans-aubeeluck', '2017-08-21 01:02:47', '', NULL, 0),
(358, 'Ornella Françoise', 'ornella-francoise', '2017-08-21 01:03:07', '', NULL, 0),
(359, 'Virginie Raoul', 'virginie-raoul', '2017-08-21 01:03:23', '', NULL, 0),
(360, 'Manisha Fokeer', 'manisha-fokeer', '2017-08-21 01:03:41', '', NULL, 0),
(361, 'Percy Chan', 'percy-chan', '2017-08-21 01:04:11', '', NULL, 0),
(362, 'Monalisa Chinda', 'monalisa-chinda', '2017-08-21 01:05:37', '', NULL, 0),
(363, 'Desmond Elliot', 'desmond-elliot', '2017-08-21 01:05:59', '', NULL, 0),
(364, 'Memry Savanhu', 'memry-savanhu', '2017-08-21 01:06:15', '', NULL, 0),
(365, 'Joy Scrase', 'joy-scrase', '2017-08-21 01:06:38', '', NULL, 0),
(366, 'Kenneth Okolie', 'kenneth-okolie', '2017-08-21 01:06:56', '', NULL, 0),
(367, 'Uru Eke', 'uru-eke', '2017-08-21 01:07:17', '', NULL, 0),
(368, 'Joy Nice', 'joy-nice', '2017-08-21 01:07:34', '', NULL, 0),
(369, 'Mike Vogel', 'mike-vogel', '2017-08-21 01:07:54', '', NULL, 0),
(370, 'Rachelle LeFevre', 'rachelle-lefevre', '2017-08-21 01:08:18', '', NULL, 0),
(371, 'Dean Norris', 'dean-norris', '2017-08-21 01:08:39', '', NULL, 0),
(372, 'Colin Ford', 'colin-ford', '2017-08-21 01:08:55', '', NULL, 0),
(373, 'Kylie Bunbury', 'kylie-bunbury', '2017-08-21 01:09:13', '', NULL, 0),
(374, 'Alexander Koch', 'alexander-koch', '2017-08-21 01:09:39', '', NULL, 0),
(375, 'Majid Michel', 'majid-michel', '2017-08-21 01:10:01', '', NULL, 0),
(376, 'Mbong Amata', 'mbong-amata', '2017-08-21 01:10:19', '', NULL, 0),
(377, 'IK Ogbonna', 'ik-ogbonna', '2017-08-21 01:10:36', '', NULL, 0),
(378, 'Diana Yekinni', 'diana-yekinni', '2017-08-21 01:10:58', '', NULL, 0),
(379, 'Stephanie Linus', 'stephanie-linus', '2017-08-21 01:11:13', '', NULL, 0),
(380, 'Zubaida Ibrahim Fagge', 'zubaida-ibrahim-fagge', '2017-08-21 01:11:32', '', NULL, 0),
(381, 'Darwin Shaw', 'darwin-shaw', '2017-08-21 01:11:51', '', NULL, 0),
(382, 'Liz Benson Ameya', 'liz-benson-ameya', '2017-08-21 01:12:18', '', NULL, 0),
(383, 'Joseph Mourtcho', 'joseph-mourtcho', '2017-08-21 01:13:20', '', NULL, 0),
(384, 'Dorine Abolo', 'dorine-abolo', '2017-08-21 01:13:37', '', NULL, 0),
(385, 'Nasser Menkes', 'nasser-menkes', '2017-08-21 01:14:11', '', NULL, 0),
(386, 'Karine Ezembe', 'karine-ezembe', '2017-08-21 01:14:37', '', NULL, 0),
(387, 'Joselyn Dumas', 'joselyn-dumas', '2017-08-21 01:15:01', '', NULL, 0),
(388, 'Chrsitabel Ekeh', 'chrsitabel-ekeh', '2017-08-21 01:15:19', '', NULL, 0),
(389, 'Jasmine Baroudi', 'jasmine-baroudi', '2017-08-21 01:15:53', '', NULL, 0),
(390, 'Nikki Samonas', 'nikki-samonas', '2017-08-21 01:16:12', '', NULL, 0),
(391, 'Mert Firat', 'mert-firat', '2017-08-21 01:16:37', '', NULL, 0),
(392, 'Alican Yucesoy', 'alican-yucesoy', '2017-08-21 01:16:53', '', NULL, 0),
(393, 'Ismael Demirci', 'ismael-demirci', '2017-08-21 01:17:21', '', NULL, 0),
(394, 'Songul Oden', 'songul-oden', '2017-08-21 01:17:56', '', NULL, 0),
(395, 'Mateus Solano', 'mateus-solano', '2017-08-21 01:19:15', '', NULL, 0),
(396, 'Klara Castanho', 'klara-castanho', '2017-08-21 01:20:35', '', NULL, 0),
(397, 'Juliano Cazarré', 'juliano-cazarre', '2017-08-21 01:20:54', '', NULL, 0),
(398, 'Tope Adeloye', 'tope-adeloye', '2017-08-21 01:21:10', '', NULL, 0),
(399, 'Oluwaseun Ademefun', 'oluwaseun-ademefun', '2017-08-21 01:21:26', '', NULL, 0),
(400, 'Segun Akinola', 'segun-akinola', '2017-08-21 01:21:51', '', NULL, 0),
(401, 'Assirifix Armamd', 'assirifix-armamd', '2017-08-21 01:22:12', '', NULL, 0),
(402, 'Gohou Michel', 'gohou-michel', '2017-08-21 01:22:33', '', NULL, 0),
(403, 'Bonnie Mbuli', 'bonnie-mbuli', '2017-08-21 01:22:52', '', NULL, 0),
(404, 'Bongo Mbutuma', 'bongo-mbutuma', '2017-08-21 01:23:08', '', NULL, 1),
(405, 'Bruna Marquezine', 'bruna-marquezine', '2017-08-21 01:23:52', '', NULL, 0),
(406, 'Humberto Martins', 'humberto-martins', '2017-08-21 01:24:07', '', NULL, 0),
(407, 'Viviane Pasmanter', 'viviane-pasmanter', '2017-08-21 01:24:23', '', NULL, 0),
(408, 'Erica Januza', 'erica-januza', '2017-08-21 01:25:39', '', NULL, 0),
(409, 'Fabricio Boliveira', 'fabricio-boliveira', '2017-08-21 01:25:55', '', NULL, 0),
(410, 'Rosa Marya Colin', 'rosa-marya-colin', '2017-08-21 01:26:26', '', NULL, 0),
(411, 'Haroldo Costa', 'haroldo-costa', '2017-08-21 01:26:46', '', NULL, 0),
(412, 'Erom Cordeiro', 'erom-cordeiro', '2017-08-21 01:27:25', '', NULL, 0),
(413, 'Bruno Belarmino', 'bruno-belarmino', '2017-08-21 01:27:40', '', NULL, 0),
(414, 'Nicolas Trevijano', 'nicolas-trevijano', '2017-08-21 01:27:58', '', NULL, 0),
(415, 'Ademir Emboava', 'ademir-emboava', '2017-08-21 01:28:15', '', NULL, 0),
(416, 'Maria Clara Spinelli', 'maria-clara-spinelli', '2017-08-21 01:28:31', '', NULL, 0),
(417, 'Rui Ricardo Dias', 'rui-ricardo-dias', '2017-08-21 01:28:51', '', NULL, 0),
(418, 'Fabiana Gugli', 'fabiana-gugli', '2017-08-21 01:29:14', '', NULL, 1),
(419, 'Sola Sobowale', 'sola-sobowale', '2017-08-21 01:29:36', '', NULL, 0),
(420, 'Keppy Ekpeyong', 'keppy-ekpeyong', '2017-08-21 01:29:52', '', NULL, 0),
(421, 'Fausat Balogun', 'fausat-balogun', '2017-08-21 01:30:10', '', NULL, 0),
(422, 'Aisha Ismael', 'aisha-ismael', '2017-08-21 01:30:25', '', NULL, 1),
(423, 'Lillian Amah Aluko', 'lillian-amah-aluko', '2017-08-21 01:30:44', '', NULL, 0),
(424, 'Femi Branch', 'femi-branch', '2017-08-21 01:31:04', '', NULL, 0),
(425, 'Alex Usifo Omiagbo', 'alex-usifo-omiagbo', '2017-08-21 01:31:28', '', NULL, 1),
(426, 'Ruth Kadiri', 'ruth-kadiri', '2017-08-21 01:31:45', '', NULL, 0),
(427, 'Anabel Okey Mbaonu', 'anabel-okey-mbaonu', '2017-08-21 01:32:22', '', NULL, 0),
(428, 'Chizoba Michel', 'chizoba-michel', '2017-08-21 01:32:36', '', NULL, 0),
(429, 'N\'dry Missa', 'ndry-missa', '2017-08-21 01:33:00', '', NULL, 0),
(430, 'Roger Ayekoe', 'roger-ayekoe', '2017-08-21 01:33:17', '', NULL, 0),
(431, 'Fyfee Kallo Kebe', 'fyfee-kallo-kebe', '2017-08-21 01:33:39', '', NULL, 0),
(432, 'Aicha Keita', 'aicha-keita', '2017-08-21 01:33:55', '', NULL, 0),
(433, 'Leyti Fall', 'leyti-fall', '2017-08-21 01:34:30', '', NULL, 0),
(434, 'Aissa Maiga', 'aissa-maiga', '2017-08-21 01:34:47', '', NULL, 0),
(435, 'Djolof Mbengue', 'djolof-mbengue', '2017-08-21 01:35:50', '', NULL, 0),
(436, 'Judith Audu', 'judith-audu', '2017-08-21 01:36:09', '', NULL, 0),
(437, 'Stan Nze', 'stan-nze', '2017-08-21 01:36:28', '', NULL, 0),
(438, 'Rotimi Salami', 'rotimi-salami', '2017-08-21 01:36:50', '', NULL, 0),
(439, 'Ijeoma Grace Agu', 'ijeoma-grace-agu', '2017-08-21 01:37:09', '', NULL, 0),
(440, 'Irene Adotey', 'irene-adotey', '2017-08-21 01:37:25', '', NULL, 0),
(441, 'Adjetey Anang', 'adjetey-anang', '2017-08-21 01:37:43', '', NULL, 1),
(442, 'Miranda Bailey', 'miranda-bailey', '2017-08-21 01:38:00', '', NULL, 0),
(443, 'David Dontoh', 'david-dontoh', '2017-08-21 01:38:19', '', NULL, 0),
(444, 'Yvonne Okoro', 'yvonne-okoro', '2017-08-21 01:38:33', '', NULL, 0),
(445, 'Fati Millogo', 'fati-millogo', '2017-08-21 01:38:51', '', NULL, 0),
(446, 'Mohamadou Tiendrébéogo', 'mohamadou-tiendrebeogo', '2017-08-21 01:40:11', '', NULL, 0),
(447, 'Fredérick Soré', 'frederick-sore', '2017-08-21 01:40:34', '', NULL, 0),
(448, 'Pauli ne Ouattara', 'pauli-ne-ouattara', '2017-08-21 01:41:34', '', NULL, 0),
(449, 'Teyonah Parris', 'teyonah-parris', '2017-08-21 01:43:19', '', NULL, 0),
(450, 'Brian White', 'brian-white', '2017-08-21 01:43:37', '', NULL, 0),
(451, 'Edwina Findley Dickerson', 'edwina-findley-dickerson', '2017-08-21 01:43:54', '', NULL, 0),
(452, 'Macy Gray', 'macy-gray', '2017-08-21 01:44:10', '', NULL, 0),
(453, 'Nse Ikpe-Etim', 'nse-ikpe-etim', '2017-08-21 01:44:56', '', NULL, 0),
(454, 'Ama Ampofo', 'ama-ampofo', '2017-08-21 01:45:26', '', NULL, 0),
(455, 'Bimbo Manuel', 'bimbo-manuel', '2017-08-21 01:45:45', '', NULL, 0),
(456, 'Sika Osei', 'sika-osei', '2017-08-21 01:46:01', '', NULL, 0),
(457, 'Funlola Aofiyebi-Raimi', 'funlola-aofiyebi-raimi', '2017-08-21 01:46:19', '', NULL, 0),
(458, 'Marlon Mave', 'marlon-mave', '2017-08-21 01:46:35', '', NULL, 0),
(459, 'Kofi Middleton Mends', 'kofi-middleton-mends', '2017-08-21 01:46:54', '', NULL, 0),
(460, 'Fritz Baffour', 'fritz-baffour', '2017-08-21 01:48:03', '', NULL, 0),
(461, 'Rama Brew', 'rama-brew', '2017-08-21 01:48:21', '', NULL, 0),
(462, 'Bibie Brew', 'bibie-brew', '2017-08-21 01:48:39', '', NULL, 1),
(463, 'Vivienne Achor', 'vivienne-achor', '2017-08-21 01:49:03', '', NULL, 0),
(464, 'Irène Opare', 'irene-opare', '2017-08-21 01:49:44', '', NULL, 0),
(465, 'OC Ukeje', 'oc-ukeje', '2017-08-21 01:50:35', '', NULL, 0),
(466, 'Elorm Adablah', 'elorm-adablah', '2017-08-21 01:51:37', '', NULL, 0),
(467, 'Edem Agbenyame', 'edem-agbenyame', '2017-08-21 01:51:58', '', NULL, 0),
(468, 'Franck Aidam', 'franck-aidam', '2017-08-21 01:52:18', '', NULL, 0),
(469, 'Joseph Benjamin', 'joseph-benjamin', '2017-08-21 01:53:14', '', NULL, 0),
(470, 'Chris Attoh', 'chris-attoh', '2017-08-21 01:53:39', '', NULL, 0),
(471, 'Lydia Forson', 'lydia-forson', '2017-08-21 01:54:51', '', NULL, 0),
(472, 'Kwame Shela-Kayi', 'kwame-shela-kayi', '2017-08-21 01:55:32', '', '7ca83d9ce58383948d5499659388168d.jpeg', 0),
(473, 'Ecow Smith Asante', 'ecow-smith-asante', '2017-08-21 01:55:48', '', '3104dcd13f97ab40d678641f5edd1b85.jpeg', 0),
(474, 'Naa Ashorkor Mensah', 'naa-ashorkor-mensah', '2017-08-21 01:56:04', '', 'a9d4249a2f2d4374aa21e01074e6866a.jpeg', 0);

-- --------------------------------------------------------

--
-- Structure de la table `actor_country`
--

CREATE TABLE `actor_country` (
  `id` int(11) NOT NULL,
  `actor_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `catalog`
--

CREATE TABLE `catalog` (
  `id` int(11) NOT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `type` enum('FSA','ESA','WORLD') COLLATE utf8_unicode_ci DEFAULT NULL,
  `token` varchar(16) COLLATE utf8_unicode_ci NOT NULL COMMENT 'code unique du catalogue',
  `criteria` longtext COLLATE utf8_unicode_ci COMMENT 'les parametres ou critères de recherche(DC2Type:array)',
  `createAt` datetime DEFAULT NULL COMMENT 'la dete de creation du catalogue'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='represente le catalogue des movies présentés';

--
-- Contenu de la table `catalog`
--

INSERT INTO `catalog` (`id`, `creator_id`, `type`, `token`, `criteria`, `createAt`) VALUES
(1, 518, 'FSA', 'MDExYjYyNGFjYmE4', 'a:0:{}', '2018-08-14 09:19:42'),
(2, 518, 'FSA', 'M2UyNjcyYzlmZDRk', 'a:4:{s:9:"published";s:3:"yes";s:10:"order_name";s:3:"ASC";s:9:"search_on";s:1:"1";s:6:"_token";s:43:"hqAFkhQcZMB2S8IDGQsXPIzJT46q0rLVZELBNAGHxCY";}', '2018-08-14 09:21:03'),
(3, 518, 'FSA', 'OTA0Y2I2NjdkMjBl', 'a:0:{}', '2018-08-14 13:56:36');

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

CREATE TABLE `category` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movie_nbr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='les différentes catégories de film';

--
-- Contenu de la table `category`
--

INSERT INTO `category` (`id`, `name`, `slug`, `movie_nbr`) VALUES
(2, 'Films', 'films', 6),
(3, 'Documentaires', 'documentaires', 0),
(4, 'Séries', 'series', 24),
(5, 'Animations', 'animations', 1),
(6, 'Télénovelas', 'telenovelas', 16),
(7, 'Magazine', 'magazine', 1),
(8, 'Mini-séries', 'mini-series', 1),
(9, 'Téléfilms', 'telefilms', 0),
(10, 'Nollywood', 'nollywood', 0);

-- --------------------------------------------------------

--
-- Structure de la table `country`
--

CREATE TABLE `country` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `code` varchar(4) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le code iso de ce pays',
  `locale` varchar(4) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le code de la langue parlée',
  `cnt_code` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `cnt_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_in_european_union` tinyint(1) DEFAULT NULL,
  `movie_nbr` int(11) NOT NULL,
  `actor_nbr` int(11) DEFAULT NULL,
  `producer_nbr` int(11) DEFAULT NULL,
  `director_nbr` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `country`
--

INSERT INTO `country` (`id`, `name`, `slug`, `code`, `locale`, `cnt_code`, `cnt_name`, `is_in_european_union`, `movie_nbr`, `actor_nbr`, `producer_nbr`, `director_nbr`) VALUES
(49518, 'Rwanda', 'rwanda', 'RW', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(51537, 'Somalie', 'somalie', 'SO', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(69543, 'Yémen', 'yemen', 'YE', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(99237, 'Irak', 'irak', 'IQ', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(102358, 'Arabie saoudite', 'arabie-saoudite', 'SA', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(130758, 'Iran', 'iran', 'IR', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(146669, 'Chypre', 'chypre', 'CY', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(149590, 'Tanzanie', 'tanzanie', 'TZ', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(163843, 'Syrie', 'syrie', 'SY', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(174982, 'Arménie', 'armenie', 'AM', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(192950, 'Kenya', 'kenya', 'KE', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(203312, 'RDC', 'rdc', 'CD', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(223816, 'Djibouti', 'djibouti', 'DJ', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(226074, 'Ouganda', 'ouganda', 'UG', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(239880, 'Centrafrique', 'centrafrique', 'CF', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(241170, 'Seychelles', 'seychelles', 'SC', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(248816, 'Jordanie', 'jordanie', 'JO', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(272103, 'Liban', 'liban', 'LB', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(285570, 'Koweït', 'koweit', 'KW', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(286963, 'Oman', 'oman', 'OM', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(289688, 'Qatar', 'qatar', 'QA', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(290291, 'Bahreïn', 'bahrein', 'BH', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(290557, 'Émirats Arabes Unis', 'emirats-arabes-unis', 'AE', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(294640, 'Israël', 'israel', 'IL', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(298795, 'Turquie', 'turquie', 'TR', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(337996, 'Éthiopie', 'ethiopie', 'ET', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(338010, 'Érythrée', 'erythree', 'ER', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(357994, 'Égypte', 'egypte', 'EG', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(366755, 'Soudan', 'soudan', 'SD', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(390903, 'Grèce', 'grece', 'GR', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(433561, 'Burundi', 'burundi', 'BI', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(453733, 'Estonie', 'estonie', 'EE', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(458258, 'Lettonie', 'lettonie', 'LV', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(587116, 'Azerbaïdjan', 'azerbaidjan', 'AZ', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(597427, 'Lituanie', 'lituanie', 'LT', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(607072, 'Svalbard et Jan Mayen', 'svalbard-et-jan-mayen', 'SJ', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(614540, 'Géorgie', 'georgie', 'GE', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(617790, 'Moldavie', 'moldavie', 'MD', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(630336, 'Biélorussie', 'bielorussie', 'BY', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(660013, 'Finlande', 'finlande', 'FI', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(661882, 'Îles Åland', 'iles-aland', 'AX', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(690791, 'Ukraine', 'ukraine', 'UA', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(718075, 'Macédoine', 'macedoine', 'MK', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(719819, 'Hongrie', 'hongrie', 'HU', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(732800, 'Bulgarie', 'bulgarie', 'BG', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(783754, 'Albanie', 'albanie', 'AL', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(798544, 'Pologne', 'pologne', 'PL', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(798549, 'Roumanie', 'roumanie', 'RO', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(831053, 'Kosovo', 'kosovo', 'XK', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(878675, 'Zimbabwe', 'zimbabwe', 'ZW', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(895949, 'Zambie', 'zambie', 'ZM', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(921929, 'Comores', 'comores', 'KM', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(927384, 'Malawi', 'malawi', 'MW', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(932692, 'Lesotho', 'lesotho', 'LS', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(933860, 'Botswana', 'botswana', 'BW', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(934292, 'Maurice', 'maurice', 'MU', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(934841, 'Swaziland', 'swaziland', 'SZ', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(935317, 'Réunion', 'reunion', 'RE', 'fr', 'AF', 'Afrique', 1, 0, 0, 0, 0),
(953987, 'Afrique du Sud', 'afrique-du-sud', 'ZA', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(1024031, 'Mayotte', 'mayotte', 'YT', 'fr', 'AF', 'Afrique', 1, 0, 0, 0, 0),
(1036973, 'Mozambique', 'mozambique', 'MZ', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(1062947, 'Madagascar', 'madagascar', 'MG', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(1149361, 'Afghanistan', 'afghanistan', 'AF', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1168579, 'Pakistan', 'pakistan', 'PK', 'fr', 'AS', 'Asie', 0, 1, 0, 0, 0),
(1210997, 'Bangladesh', 'bangladesh', 'BD', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1218197, 'Turkménistan', 'turkmenistan', 'TM', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1220409, 'Tadjikistan', 'tadjikistan', 'TJ', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1227603, 'Sri Lanka', 'sri-lanka', 'LK', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1252634, 'Bhoutan', 'bhoutan', 'BT', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1269750, 'Inde', 'inde', 'IN', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1282028, 'Maldives', 'maldives', 'MV', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1282588, 'Territoire britannique de l\'oc', 'territoire-britannique-de-loc', 'IO', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1282988, 'Népal', 'nepal', 'NP', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1327865, 'Myanmar', 'myanmar', 'MM', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1512440, 'Ouzbékistan', 'ouzbekistan', 'UZ', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1522867, 'Kazakhstan', 'kazakhstan', 'KZ', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1527747, 'Kirghizistan', 'kirghizistan', 'KG', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1546748, 'Terres australes françaises', 'terres-australes-francaises', 'TF', 'fr', 'AN', 'Antarctique', 0, 0, 0, 0, 0),
(1547314, 'Île Heard et îles McDonald', 'ile-heard-et-iles-mcdonald', 'HM', 'fr', 'AN', 'Antarctique', 0, 0, 0, 0, 0),
(1547376, 'Îles Cocos', 'iles-cocos', 'CC', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1559582, 'Palaos', 'palaos', 'PW', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(1562822, 'Vietnam', 'vietnam', 'VN', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1605651, 'Thaïlande', 'thailande', 'TH', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1643084, 'Indonésie', 'indonesie', 'ID', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1655842, 'Laos', 'laos', 'LA', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1668284, 'Taïwan', 'taiwan', 'TW', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1694008, 'Philippines', 'philippines', 'PH', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1733045, 'Malaisie', 'malaisie', 'MY', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1814991, 'Chine', 'chine', 'CN', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1819730, 'Hong Kong', 'hong-kong', 'HK', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1820814, 'Brunéi Darussalam', 'brunei-darussalam', 'BN', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1821275, 'Macao', 'macao', 'MO', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1831722, 'Cambodge', 'cambodge', 'KH', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1835841, 'Corée du Sud', 'coree-du-sud', 'KR', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1861060, 'Japon', 'japon', 'JP', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1873107, 'Corée du Nord', 'coree-du-nord', 'KP', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1880251, 'Singapour', 'singapour', 'SG', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(1899402, 'Îles Cook', 'iles-cook', 'CK', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(1966436, 'Timor Oriental', 'timor-oriental', 'TL', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2017370, 'Russie', 'russie', 'RU', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(2029969, 'Mongolie', 'mongolie', 'MN', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(2077456, 'Australie', 'australie', 'AU', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2078138, 'Île Christmas', 'ile-christmas', 'CX', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(2080185, 'Îles Marshall', 'iles-marshall', 'MH', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2081918, 'Micronésie', 'micronesie', 'FM', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2088628, 'Papouasie-Nouvelle Guinée', 'papouasie-nouvelle-guinee', 'PG', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2103350, 'Îles Salomon', 'iles-salomon', 'SB', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2110297, 'Tuvalu', 'tuvalu', 'TV', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2110425, 'Nauru', 'nauru', 'NR', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2134431, 'Vanuatu', 'vanuatu', 'VU', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2139685, 'Nouvelle-Calédonie', 'nouvelle-caledonie', 'NC', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2155115, 'Île Norfolk', 'ile-norfolk', 'NF', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2186224, 'Nouvelle-Zélande', 'nouvelle-zelande', 'NZ', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2205218, 'Fidji', 'fidji', 'FJ', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(2215636, 'Libye', 'libye', 'LY', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2233387, 'Cameroun', 'cameroun', 'CM', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2245662, 'Sénégal', 'senegal', 'SN', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2260494, 'Congo-Brazzaville', 'congo-brazzaville', 'CG', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2264397, 'Portugal', 'portugal', 'PT', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2275384, 'Liberia', 'liberia', 'LR', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2287781, 'Côte d\'Ivoire', 'cote-divoire', 'CI', 'fr', 'AF', 'Afrique', 0, 4, 0, 0, 0),
(2300660, 'Ghana', 'ghana', 'GH', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2309096, 'Guinée équatoriale', 'guinee-equatoriale', 'GQ', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2328926, 'Nigeria', 'nigeria', 'NG', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2361809, 'Burkina Faso', 'burkina-faso', 'BF', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2363686, 'Togo', 'togo', 'TG', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2372248, 'Guinée-Bissau', 'guinee-bissau', 'GW', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2378080, 'Mauritanie', 'mauritanie', 'MR', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2395170, 'Bénin', 'benin', 'BJ', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2400553, 'Gabon', 'gabon', 'GA', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2403846, 'Sierra Leone', 'sierra-leone', 'SL', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2410758, 'São Tomé-et-Príncipe', 'sao-tome-et-principe', 'ST', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2411586, 'Gibraltar', 'gibraltar', 'GI', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2413451, 'Gambie', 'gambie', 'GM', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2420477, 'Guinée', 'guinee', 'GN', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2434508, 'Tchad', 'tchad', 'TD', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2440476, 'Niger', 'niger', 'NE', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2453866, 'Mali', 'mali', 'ML', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2461445, 'Sahara Occidental', 'sahara-occidental', 'EH', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2464461, 'Tunisie', 'tunisie', 'TN', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2510769, 'Espagne', 'espagne', 'ES', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2542007, 'Maroc', 'maroc', 'MA', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(2562770, 'Malte', 'malte', 'MT', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2589581, 'Algérie', 'algerie', 'DZ', 'fr', 'AF', 'Afrique', 0, 1, 0, 0, 0),
(2622320, 'Îles Féroé', 'iles-feroe', 'FO', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(2623032, 'Danemark', 'danemark', 'DK', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2629691, 'Islande', 'islande', 'IS', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(2635167, 'Royaume-Uni', 'royaume-uni', 'GB', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2658434, 'Suisse', 'suisse', 'CH', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(2661886, 'Suède', 'suede', 'SE', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2750405, 'Pays-Bas', 'pays-bas', 'NL', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2782113, 'Autriche', 'autriche', 'AT', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2802361, 'Belgique', 'belgique', 'BE', 'fr', 'EU', 'Europe', 1, 1, 0, 0, 0),
(2921044, 'Allemagne', 'allemagne', 'DE', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2960313, 'Luxembourg', 'luxembourg', 'LU', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2963597, 'Irlande', 'irlande', 'IE', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(2993457, 'Monaco', 'monaco', 'MC', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3017382, 'France', 'france', 'FR', 'fr', 'EU', 'Europe', 1, 1, 0, 0, 0),
(3041565, 'Andorre', 'andorre', 'AD', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3042058, 'Liechtenstein', 'liechtenstein', 'LI', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3042142, 'Jersey', 'jersey', 'JE', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3042225, 'Île de Man', 'ile-de-man', 'IM', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3042362, 'Guernesey', 'guernesey', 'GG', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3057568, 'Slovaquie', 'slovaquie', 'SK', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(3077311, 'République tchèque', 'republique-tcheque', 'CZ', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(3144096, 'Norvège', 'norvege', 'NO', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3164670, 'Vatican', 'vatican', 'VA', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3168068, 'Saint-Marin', 'saint-marin', 'SM', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3175395, 'Italie', 'italie', 'IT', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(3190538, 'Slovénie', 'slovenie', 'SI', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(3194884, 'Monténégro', 'montenegro', 'ME', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3202326, 'Croatie', 'croatie', 'HR', 'fr', 'EU', 'Europe', 1, 0, 0, 0, 0),
(3277605, 'Bosnie-Herzégovine', 'bosnie-herzegovine', 'BA', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(3351879, 'Angola', 'angola', 'AO', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(3355338, 'Namibie', 'namibie', 'NA', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(3370751, 'Sainte-Hélène', 'sainte-helene', 'SH', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(3371123, 'Île Bouvet', 'ile-bouvet', 'BV', 'fr', 'AN', 'Antarctique', 0, 0, 0, 0, 0),
(3374084, 'Barbade', 'barbade', 'BB', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3374766, 'Cap-Vert', 'cap-vert', 'CV', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0),
(3378535, 'Guyana', 'guyana', 'GY', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3381670, 'Guyane', 'guyane', 'GF', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3382998, 'Surinam', 'surinam', 'SR', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3424932, 'Saint-Pierre et Miquelon', 'saint-pierre-et-miquelon', 'PM', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3425505, 'Groenland', 'groenland', 'GL', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3437598, 'Paraguay', 'paraguay', 'PY', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3439705, 'Uruguay', 'uruguay', 'UY', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3469034, 'Brésil', 'bresil', 'BR', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3474414, 'Îles Malouines', 'iles-malouines', 'FK', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3474415, 'Géorgie du Sud-et-les îles San', 'georgie-du-sud-et-les-iles-san', 'GS', 'fr', 'AN', 'Antarctique', 0, 0, 0, 0, 0),
(3489940, 'Jamaïque', 'jamaique', 'JM', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3508796, 'République Dominicaine', 'republique-dominicaine', 'DO', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3562981, 'Cuba', 'cuba', 'CU', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3570311, 'Martinique', 'martinique', 'MQ', 'fr', 'NA', 'Amérique du Nord', 1, 0, 0, 0, 0),
(3572887, 'Bahamas', 'bahamas', 'BS', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3573345, 'Bermudes', 'bermudes', 'BM', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3573511, 'Anguilla', 'anguilla', 'AI', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3573591, 'Trinidad et Tobago', 'trinidad-et-tobago', 'TT', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3575174, 'Saint-Christophe-et-Niévès', 'saint-christophe-et-nieves', 'KN', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3575830, 'Dominique', 'dominique', 'DM', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3576396, 'Antigua et Barbuda', 'antigua-et-barbuda', 'AG', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3576468, 'Sainte-Lucie', 'sainte-lucie', 'LC', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3576916, 'Îles Turques-et-Caïques', 'iles-turques-et-caiques', 'TC', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3577279, 'Aruba', 'aruba', 'AW', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3577718, 'Îles Vierges', 'iles-vierges', 'VG', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3577815, 'Saint-Vincent-et-les Grenadine', 'saint-vincent-et-les-grenadine', 'VC', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3578097, 'Montserrat', 'montserrat', 'MS', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3578421, 'Saint-Martin', 'saint-martin', 'MF', 'fr', 'NA', 'Amérique du Nord', 1, 0, 0, 0, 0),
(3578476, 'Saint-Barthélémy', 'saint-barthelemy', 'BL', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3579143, 'Guadeloupe', 'guadeloupe', 'GP', 'fr', 'NA', 'Amérique du Nord', 1, 0, 0, 0, 0),
(3580239, 'Grenade', 'grenade', 'GD', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3580718, 'Îles Caïmans', 'iles-caimans', 'KY', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3582678, 'Belize', 'belize', 'BZ', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3585968, 'Salvador', 'salvador', 'SV', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3595528, 'Guatemala', 'guatemala', 'GT', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3608932, 'Honduras', 'honduras', 'HN', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3617476, 'Nicaragua', 'nicaragua', 'NI', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3624060, 'Costa Rica', 'costa-rica', 'CR', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3625428, 'Vénézuéla', 'venezuela', 'VE', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3658394, 'Équateur', 'equateur', 'EC', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3686110, 'Colombie', 'colombie', 'CO', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3703430, 'Panama', 'panama', 'PA', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3723988, 'Haïti', 'haiti', 'HT', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(3865483, 'Argentine', 'argentine', 'AR', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3895114, 'Chili', 'chili', 'CL', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3923057, 'Bolivie', 'bolivie', 'BO', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3932488, 'Pérou', 'perou', 'PE', 'fr', 'SA', 'Amérique du Sud', 0, 0, 0, 0, 0),
(3996063, 'Mexique', 'mexique', 'MX', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(4030656, 'Polynésie Française', 'polynesie-francaise', 'PF', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4030699, 'Pitcairn', 'pitcairn', 'PN', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4030945, 'Kiribati', 'kiribati', 'KI', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4031074, 'Tokelau', 'tokelau', 'TK', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4032283, 'Tonga', 'tonga', 'TO', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4034749, 'Wallis-et-Futuna', 'wallis-et-futuna', 'WF', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4034894, 'Samoa', 'samoa', 'WS', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4036232, 'Nioué', 'nioue', 'NU', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4041468, 'Îles Mariannes du Nord', 'iles-mariannes-du-nord', 'MP', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4043988, 'Guam', 'guam', 'GU', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(4566966, 'Porto Rico', 'porto-rico', 'PR', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(4796775, 'Îles Vierges des États-Unis', 'iles-vierges-des-etats-unis', 'VI', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(5854968, 'Îles mineures éloignées des Ét', 'iles-mineures-eloignees-des-et', 'UM', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(5880801, 'Samoa américaines', 'samoa-americaines', 'AS', 'fr', 'OC', 'Océanie', 0, 0, 0, 0, 0),
(6251999, 'Canada', 'canada', 'CA', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(6252001, 'États-Unis', 'etats-unis', 'US', 'fr', 'NA', 'Amérique du Nord', 0, 1, 0, 0, 0),
(6254930, 'Territoire palestinien', 'territoire-palestinien', 'PS', 'fr', 'AS', 'Asie', 0, 0, 0, 0, 0),
(6290252, 'Serbie', 'serbie', 'RS', 'fr', 'EU', 'Europe', 0, 0, 0, 0, 0),
(6697173, 'Antarctique', 'antarctique', 'AQ', 'fr', 'AN', 'Antarctique', 0, 0, 0, 0, 0),
(7609695, 'Saint-Martin', 'saint-martin-1', 'SX', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(7626836, 'Curaçao', 'curacao', 'CW', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(7626844, 'Bonaire, Saint-Eustache et Sab', 'bonaire-saint-eustache-et-sab', 'BQ', 'fr', 'NA', 'Amérique du Nord', 0, 0, 0, 0, 0),
(7909807, 'Sud-Soudan', 'sud-soudan', 'SS', 'fr', 'AF', 'Afrique', 0, 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` datetime NOT NULL,
  `email_received` int(11) NOT NULL,
  `email_processed` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `department`
--

INSERT INTO `department` (`id`, `name`, `slug`, `email`, `create_at`, `email_received`, `email_processed`) VALUES
(1, 'acquisition', 'acquisition', 'acquisition@coteouest.tv', '2018-07-11 00:00:00', 0, 0),
(2, 'communication', 'communication', 'communication@coteouest.tv\n', '2018-07-11 00:00:00', 0, 0),
(3, 'commercial', 'commercial', 'sales@coteouest.tv', '2018-07-11 00:00:00', 4, 0);

-- --------------------------------------------------------

--
-- Structure de la table `director`
--

CREATE TABLE `director` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movie_nbr` int(11) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='cette table enregistre les réalisateurs de film';

--
-- Contenu de la table `director`
--

INSERT INTO `director` (`id`, `name`, `description`, `slug`, `image`, `movie_nbr`, `create_at`) VALUES
(129, 'Grace Kahaki Munthali', '', 'grace-kahaki-munthali', NULL, 0, '2017-08-22 11:52:43'),
(130, 'Tate Taylor', '', 'tate-taylor', NULL, 0, '2017-08-22 13:14:39'),
(131, 'Mvondo Edouadoua', '', 'mvondo-edouadoua', NULL, 0, '2017-08-22 13:15:05'),
(132, 'Neil Schell', '', 'neil-schell', NULL, 0, '2017-08-22 13:15:17'),
(133, 'Philippe Bresson', '', 'philippe-bresson', NULL, 0, '2017-08-22 13:15:28'),
(134, 'Grace KIHAKI', '', 'grace-kihaki', NULL, 0, '2017-08-22 13:15:45'),
(135, 'Mark S. Waters', '', 'mark-s-waters', NULL, 0, '2017-08-22 13:15:57'),
(136, 'Jim BIMBONER', '', 'jim-bimboner', NULL, 0, '2017-08-22 13:16:31'),
(137, 'Denise Saraceni', '', 'denise-saraceni', NULL, 1, '2017-08-22 13:16:45'),
(138, 'Reynaldo Boury', '', 'reynaldo-boury', NULL, 0, '2017-08-22 13:16:59'),
(139, 'Jayme Monjardi', '', 'jayme-monjardi', NULL, 0, '2017-08-22 13:17:09'),
(140, 'Ron Clements', '', 'ron-clements', NULL, 0, '2017-08-22 13:17:21'),
(141, 'John Musker', '', 'john-musker', NULL, 0, '2017-08-22 13:17:34'),
(142, 'Alain Gomis', '', 'alain-gomis', NULL, 1, '2017-08-22 13:17:48'),
(143, 'Amora Mautner', '', 'amora-mautner', NULL, 1, '2017-08-22 13:18:04'),
(144, 'Carlos Araujo', '', 'carlos-araujo', NULL, 0, '2017-08-22 13:18:17'),
(145, 'Luis Henrique Rios', '', 'luis-henrique-rios', NULL, 0, '2017-08-22 13:18:33'),
(146, 'Aatish Kapadia', '', 'aatish-kapadia', NULL, 0, '2017-08-22 13:18:44'),
(147, 'Ricardo Waddington', '', 'ricardo-waddington', NULL, 0, '2017-08-22 13:18:57'),
(148, 'Euclydes Marinho', '', 'euclydes-marinho', NULL, 0, '2017-08-22 13:19:14'),
(149, 'Manuel Pureza', '', 'manuel-pureza', NULL, 0, '2017-08-22 13:19:32'),
(150, 'Bronwyn Berry', '', 'bronwyn-berry', NULL, 0, '2017-08-22 13:52:45'),
(151, 'Rohan Dickson', '', 'rohan-dickson', NULL, 0, '2017-08-22 13:52:59'),
(152, 'Andrew Stanton', '', 'andrew-stanton', NULL, 0, '2017-08-22 13:53:12'),
(153, 'Lee Unkrich', '', 'lee-unkrich', NULL, 0, '2017-08-22 13:53:25'),
(154, 'Bob Walker', '', 'bob-walker', NULL, 2, '2017-08-22 13:53:39'),
(155, 'Aaron Blaise', '', 'aaron-blaise', NULL, 2, '2017-08-22 13:53:56'),
(156, 'Wolf Maya', '', 'wolf-maya', NULL, 0, '2017-08-22 13:54:34'),
(157, 'Marcos Schechtman', '', 'marcos-schechtman', NULL, 0, '2017-08-22 13:55:02'),
(158, 'Dennis Carvalho', '', 'dennis-carvalho', NULL, 1, '2017-08-22 13:55:32'),
(159, 'Chris Weitz', '', 'chris-weitz', NULL, 0, '2017-08-22 13:56:33'),
(160, 'Globo TV', '', 'globo-tv', NULL, 0, '2017-08-22 13:57:12'),
(161, 'Gloria Perez', '', 'gloria-perez', NULL, 0, '2017-08-22 13:57:35'),
(162, 'Leo Nformi', '', 'leo-nformi', NULL, 0, '2017-08-22 13:58:15'),
(163, 'Mo Abudu', '', 'mo-abudu', NULL, 0, '2017-08-22 13:58:32'),
(164, 'John Ximenes Braga', '', 'john-ximenes-braga', NULL, 0, '2017-08-22 13:59:31'),
(165, 'Dominic Burns', '', 'dominic-burns', NULL, 0, '2017-08-22 14:00:11'),
(166, 'Charmaine Zulu', '', 'charmaine-zulu', NULL, 1, '2017-08-22 14:00:46'),
(167, 'Simiyu Barasa', '', 'simiyu-barasa', NULL, 0, '2017-08-22 14:03:00'),
(168, 'Semba Communicacao', '', 'semba-communicacao', NULL, 0, '2017-08-22 14:16:27'),
(169, 'Chika Anadu', '', 'chika-anadu', NULL, 2, '2017-08-22 14:20:23'),
(170, 'José Luiz Villamarim', '', 'jose-luiz-villamarim', NULL, 0, '2017-08-22 14:20:43'),
(171, 'Tony Gilroy', '', 'tony-gilroy', NULL, 0, '2017-08-22 14:21:00'),
(172, 'Henry Selick', '', 'henry-selick', NULL, 0, '2017-08-22 14:21:25'),
(173, 'Michael Mann', '', 'michael-mann', NULL, 0, '2017-08-22 14:21:54'),
(174, 'Ridley Scott', '', 'ridley-scott', NULL, 0, '2017-08-22 14:22:07'),
(175, 'Lone Scherfig', '', 'lone-scherfig', NULL, 0, '2017-08-22 14:22:18'),
(176, 'Justin Lin', '', 'justin-lin', NULL, 0, '2017-08-22 14:22:31'),
(177, 'Tom Hanks', '', 'tom-hanks', NULL, 0, '2017-08-22 14:22:46'),
(178, 'Christian Orji', '', 'christian-orji', NULL, 0, '2017-08-22 14:25:44'),
(179, 'Moussa Haddad', '', 'moussa-haddad', NULL, 0, '2017-08-22 14:28:41'),
(180, 'Emem Isong', '', 'emem-isong', NULL, 0, '2017-08-22 14:29:03'),
(181, 'Richard Harry Nosworthy', '', 'richard-harry-nosworthy', NULL, 0, '2017-08-22 14:29:51'),
(182, 'Desmond Ovbagiele', '', 'desmond-ovbagiele', NULL, 0, '2017-08-22 14:30:23'),
(183, 'Kunle Afolayan', '', 'kunle-afolayan', NULL, 0, '2017-08-22 14:30:56'),
(184, 'Desmond Elliot', '', 'desmond-elliot', NULL, 0, '2017-08-22 14:31:16'),
(185, 'Stephanie Linus', '', 'stephanie-linus', NULL, 0, '2017-08-22 14:31:50'),
(186, 'The Flying Circus', '', 'the-flying-circus', NULL, 0, '2017-08-22 14:32:41'),
(187, 'Segun Williams', '', 'segun-williams', NULL, 0, '2017-08-22 14:35:21'),
(188, 'LL Brown', '', 'll-brown', NULL, 0, '2017-08-22 14:35:35'),
(189, 'Ruth Kadiri', '', 'ruth-kadiri', NULL, 0, '2017-08-22 14:58:52'),
(190, 'Udak-Obong Patrick', '', 'udak-obong-patrick', NULL, 0, '2017-08-22 15:00:14'),
(191, 'Leila Djansi', '', 'leila-djansi', NULL, 0, '2017-08-22 15:00:34'),
(192, 'Shirley Frimpong-Manso', '', 'shirley-frimpong-manso', NULL, 0, '2017-08-22 15:01:25'),
(195, 'Aaeo maxim', 'je sais ce que je dis ok ? ne me laisse pas aller loind e toit seigneru je sais qua c\'est ta  grace qui benie et fortifie', 'aaeo-maxim', '10bbc35e467c0f2c5f571a85b999efcf.jpeg', 1, '2018-07-20 16:32:12');

-- --------------------------------------------------------

--
-- Structure de la table `director_country`
--

CREATE TABLE `director_country` (
  `id` int(11) NOT NULL,
  `director_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='liaison entre les realisateurs et leur pays d''origine';

--
-- Contenu de la table `director_country`
--

INSERT INTO `director_country` (`id`, `director_id`, `country_id`, `create_at`) VALUES
(10, 195, 3351879, '2018-07-21 10:22:15');

-- --------------------------------------------------------

--
-- Structure de la table `ext_translations`
--

CREATE TABLE `ext_translations` (
  `id` int(11) NOT NULL,
  `locale` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `object_class` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `field` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `foreign_key` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `content` longtext COLLATE utf8_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci ROW_FORMAT=DYNAMIC;

--
-- Contenu de la table `ext_translations`
--

INSERT INTO `ext_translations` (`id`, `locale`, `object_class`, `field`, `foreign_key`, `content`) VALUES
(1, 'en', 'AppBundle\\Entity\\Language', 'name', '1', 'French'),
(2, 'en', 'AppBundle\\Entity\\Language', 'slug', '1', 'french'),
(3, 'en', 'AppBundle\\Entity\\Language', 'name', '2', 'English'),
(4, 'en', 'AppBundle\\Entity\\Language', 'slug', '2', 'english'),
(5, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'name', '6', 'I know your website address'),
(6, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'slug', '6', 'i-know-your-website-address'),
(7, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'name', '7', 'Search on google'),
(8, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'slug', '7', 'search-on-google'),
(9, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'name', '8', 'Press release / article'),
(10, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'slug', '8', 'press-release-article'),
(11, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'name', '9', 'Côte Ouest Newsletter'),
(12, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'slug', '9', 'cote-ouest-newsletter'),
(13, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'name', '10', 'Other'),
(14, 'en', 'AppBundle\\Entity\\WebsiteReferer', 'slug', '10', 'other'),
(27, 'en', 'AppBundle\\Entity\\Movie', 'tagline', '138', 'I know it'),
(28, 'en', 'AppBundle\\Entity\\Movie', 'logline', '138', 'what else'),
(29, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '138', 'Historique\n=========\nA synopsis is a writing describing the totality or an outline of a work or a science. The term is primarily known for its cinematographic use. In the film industry, this term refers to the condensed summary of a scenario. As such, he describes the outline of the story, sketches the main characters and their evolution, without going into details. Its length can vary from a few lines to several pages2. In general, it does not involve dialogues and is written in the narrative present, in a simple, often indirect style. The synopsis is, according to Vincent Pinel, "a first shaping of the narrative raw material of the film" 2. At the beginning of some works, there is a synopsis, on one or two pages, which presents in a condensed way the contents of each chapter. cool man'),
(30, 'ar', 'AppBundle\\Entity\\Movie', 'tagline', '138', 'أعرفه'),
(31, 'ar', 'AppBundle\\Entity\\Movie', 'logline', '138', 'ما الآخر'),
(32, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '138', 'لموجز هو عبارة عن كتابة تصف الكلية أو الخطوط العريضة للعمل أو العلم. هذا المصطلح معروف في المقام الأول لاستخدامه السينمائي. في صناعة الأفلام ، يشير هذا المصطلح إلى الملخص المكثف للسيناريو. على هذا النحو ، فهو يصف الخطوط العريضة للقصة ، يرسم الشخصيات الرئيسية وتطورها ، دون الخوض في التفاصيل. يمكن أن يختلف طوله من عدة أسطر إلى عدة صفحات 2. بشكل عام ، لا تتضمن الحوارات وهي مكتوبة في الحكاية السردية ، بأسلوب بسيط غير مباشر في كثير من الأحيان. ملخص الفيلم ، بحسب فينسنت بينيل ، "أول تشكيل للمواد الخام السردية في الفيلم" 2. في بداية بعض الأعمال ، هناك خلاصة ، على صفحة واحدة أو صفحتين ، والتي تقدم بطريقة مكثفة محتويات كل فصل.'),
(33, 'en', 'AppBundle\\Entity\\Genre', 'name', '1', 'Drama'),
(34, 'en', 'AppBundle\\Entity\\Genre', 'slug', '1', 'drama'),
(35, 'en', 'AppBundle\\Entity\\Genre', 'name', '4', 'Family'),
(36, 'en', 'AppBundle\\Entity\\Genre', 'slug', '4', 'family'),
(37, 'en', 'AppBundle\\Entity\\Genre', 'name', '5', 'Comedy'),
(38, 'en', 'AppBundle\\Entity\\Genre', 'slug', '5', 'comedy'),
(39, 'en', 'AppBundle\\Entity\\Genre', 'name', '7', 'Society'),
(40, 'en', 'AppBundle\\Entity\\Genre', 'slug', '7', 'society'),
(41, 'en', 'AppBundle\\Entity\\Genre', 'name', '8', 'Fashion'),
(42, 'en', 'AppBundle\\Entity\\Genre', 'slug', '8', 'fashion'),
(43, 'en', 'AppBundle\\Entity\\Genre', 'name', '9', 'Child'),
(44, 'en', 'AppBundle\\Entity\\Genre', 'slug', '9', 'child'),
(45, 'en', 'AppBundle\\Entity\\Genre', 'name', '13', 'History'),
(46, 'en', 'AppBundle\\Entity\\Genre', 'slug', '13', 'history'),
(47, 'en', 'AppBundle\\Entity\\Genre', 'name', '15', 'Mystery'),
(48, 'en', 'AppBundle\\Entity\\Genre', 'slug', '15', 'mystery'),
(49, 'en', 'AppBundle\\Entity\\Genre', 'name', '16', 'Music'),
(50, 'en', 'AppBundle\\Entity\\Genre', 'slug', '16', 'music'),
(51, 'en', 'AppBundle\\Entity\\Genre', 'name', '17', 'Horror'),
(52, 'en', 'AppBundle\\Entity\\Genre', 'slug', '17', 'horror'),
(53, 'en', 'AppBundle\\Entity\\Genre', 'name', '19', 'War'),
(54, 'en', 'AppBundle\\Entity\\Genre', 'slug', '19', 'war'),
(55, 'en', 'AppBundle\\Entity\\Genre', 'name', '20', 'Animated'),
(56, 'en', 'AppBundle\\Entity\\Genre', 'slug', '20', 'animated'),
(57, 'en', 'AppBundle\\Entity\\Language', 'name', '3', 'Original version'),
(58, 'en', 'AppBundle\\Entity\\Language', 'slug', '3', 'original-version'),
(59, 'en', 'AppBundle\\Entity\\Language', 'name', '6', 'VOST English'),
(60, 'en', 'AppBundle\\Entity\\Language', 'slug', '6', 'vost-english'),
(61, 'en', 'AppBundle\\Entity\\Language', 'name', '5', 'VOST French'),
(62, 'en', 'AppBundle\\Entity\\Language', 'slug', '5', 'vost-french'),
(63, 'en', 'AppBundle\\Entity\\Language', 'name', '9', 'Original Version dubbed in French'),
(64, 'en', 'AppBundle\\Entity\\Language', 'slug', '9', 'original-version-dubbed-in-french'),
(65, 'en', 'AppBundle\\Entity\\Language', 'name', '10', 'Original Version dubbed in English'),
(66, 'en', 'AppBundle\\Entity\\Language', 'slug', '10', 'original-version-dubbed-in-english'),
(67, 'en', 'AppBundle\\Entity\\Language', 'name', '7', 'Darija Dubbed Version'),
(68, 'en', 'AppBundle\\Entity\\Language', 'slug', '7', 'darija-dubbed-version'),
(69, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'name', '27', 'French'),
(70, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'slug', '27', 'french'),
(71, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'name', '28', 'English'),
(72, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'slug', '28', 'english'),
(73, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'name', '29', 'Portuguese'),
(74, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'slug', '29', 'portuguese'),
(75, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'name', '30', 'Arabic'),
(76, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'slug', '30', 'arabic'),
(77, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'name', '31', 'Turquish'),
(78, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'slug', '31', 'turquish'),
(79, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'name', '39', 'Other'),
(80, 'en', 'AppBundle\\Entity\\OriginalLanguage', 'slug', '39', 'other'),
(83, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '147', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(84, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '147', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(85, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '148', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(86, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '148', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(87, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '150', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(88, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '150', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(89, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '151', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(90, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '151', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(91, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '152', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(92, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '152', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(93, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '153', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(94, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '153', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(95, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '155', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(96, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '155', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(97, 'en', 'AppBundle\\Entity\\Movie', 'synopsis', '156', 'A synopsis is a writing describing the totality or outline of a work or science. The term is primarily known for its use …'),
(98, 'ar', 'AppBundle\\Entity\\Movie', 'synopsis', '156', 'لموجز هو عبارة عن كتابة تصف مجمل أو مخطط عمل أو علم. هذا المصطلح معروف في المقام الأول لاستخدامه ...'),
(99, 'en', 'AppBundle\\Entity\\Genre', 'slug', '21', 'fantastic'),
(100, 'en', 'AppBundle\\Entity\\Genre', 'name', '21', 'Fantastic'),
(101, 'en', 'AppBundle\\Entity\\Genre', 'slug', '22', 'medical'),
(102, 'en', 'AppBundle\\Entity\\Genre', 'name', '22', 'Medical'),
(103, 'en', 'AppBundle\\Entity\\Genre', 'slug', '23', 'child'),
(104, 'en', 'AppBundle\\Entity\\Genre', 'name', '23', 'Child'),
(105, 'en', 'AppBundle\\Entity\\Genre', 'slug', '24', 'politic'),
(106, 'en', 'AppBundle\\Entity\\Genre', 'name', '24', 'Politic'),
(107, 'en', 'AppBundle\\Entity\\Genre', 'slug', '26', 'adventure'),
(108, 'en', 'AppBundle\\Entity\\Genre', 'name', '26', 'Adventure'),
(109, 'en', 'AppBundle\\Entity\\Genre', 'slug', '29', 'humor'),
(110, 'en', 'AppBundle\\Entity\\Genre', 'name', '29', 'Humor'),
(111, 'en', 'AppBundle\\Entity\\Genre', 'slug', '30', 'biography'),
(112, 'en', 'AppBundle\\Entity\\Genre', 'name', '30', 'Biography'),
(113, 'en', 'AppBundle\\Entity\\Genre', 'slug', '48', 'martial-arts'),
(114, 'en', 'AppBundle\\Entity\\Genre', 'name', '48', 'Martial Arts'),
(115, 'en', 'AppBundle\\Entity\\Genre', 'slug', '49', 'entertainment'),
(116, 'en', 'AppBundle\\Entity\\Genre', 'name', '49', 'Entertainment'),
(117, 'en', 'AppBundle\\Entity\\Genre', 'slug', '50', 'astrology'),
(118, 'en', 'AppBundle\\Entity\\Genre', 'name', '50', 'Astrology'),
(119, 'en', 'AppBundle\\Entity\\Genre', 'slug', '51', 'investigation'),
(120, 'en', 'AppBundle\\Entity\\Genre', 'name', '51', 'Investigation'),
(121, 'en', 'AppBundle\\Entity\\Genre', 'slug', '54', 'environment'),
(122, 'en', 'AppBundle\\Entity\\Genre', 'name', '54', 'Environment'),
(123, 'en', 'AppBundle\\Entity\\Genre', 'slug', '55', 'cooking'),
(124, 'en', 'AppBundle\\Entity\\Genre', 'name', '55', 'Cooking');

-- --------------------------------------------------------

--
-- Structure de la table `file`
--

CREATE TABLE `file` (
  `id` int(11) NOT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le nom original du fichier sur la machine du uploader',
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le nom du fichier généré automatiquement sur la plateforme',
  `extension` varchar(5) COLLATE utf8_unicode_ci NOT NULL COMMENT 'l''extension du fichier uploadé',
  `type` enum('image','office doc','video','other','music','pdf') COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le mime type du fichier',
  `size` int(11) NOT NULL COMMENT 'la taille du fichier en octet',
  `create_at` datetime NOT NULL COMMENT 'la date d''upload du fichier sur la plateforme'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='enregistre tout les fichiers deposés sur la plateforme';

-- --------------------------------------------------------

--
-- Structure de la table `genre`
--

CREATE TABLE `genre` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movie_nbr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='enregistre le genre d''un movie';

--
-- Contenu de la table `genre`
--

INSERT INTO `genre` (`id`, `name`, `slug`, `movie_nbr`) VALUES
(1, 'Drame', 'drame', 7),
(2, 'Police', 'police', 6),
(3, 'Thriller', 'thriller', 0),
(4, 'Famille', 'famille', 0),
(5, 'Comedie', 'comedie', 0),
(6, 'Romance ', 'romance ', 0),
(7, 'Societe', 'societe', 0),
(8, 'Mode ', 'mode ', 0),
(9, 'Jeunesse', 'jeunesse', 0),
(10, 'Education ', 'education ', 0),
(11, 'Action', 'action', 0),
(12, 'Sci-Fi ', 'sci-fi ', 0),
(13, 'Histoire', 'histoire', 0),
(14, 'Culture ', 'culture ', 0),
(15, 'Mystère', 'mystere', 0),
(16, 'Musique ', 'musique ', 0),
(17, 'Horreur', 'horreur', 0),
(18, 'Western ', 'western ', 0),
(19, 'Guerre', 'guerre', 0),
(20, 'Animation ', 'animation ', 0),
(21, 'Fantastique', 'fantastique', 0),
(22, 'Medical', 'medical', 0),
(23, 'Enfant', 'enfant', 0),
(24, 'Politique', 'politique', 0),
(25, 'Sitcom', 'sitcom', 0),
(26, 'Aventure', 'aventure', 0),
(27, 'Fiction', 'fiction', 0),
(28, 'Réligion', 'religion', 0),
(29, 'Humour', 'humour', 0),
(30, 'Biographie', 'biographie', 0),
(48, 'Arts martiaux', 'arts-martiaux', 0),
(49, 'Divertissement', 'divertissement', 0),
(50, 'Astrologie', 'astrologie', 0),
(51, 'Enquête', 'enquete', 0),
(52, 'Sport', 'sport', 0),
(53, 'Epouvante', 'epouvante', 0),
(54, 'Environnement', 'environnement', 0),
(55, 'Cuisine', 'cuisine', 0);

-- --------------------------------------------------------

--
-- Structure de la table `image`
--

CREATE TABLE `image` (
  `id` int(11) NOT NULL,
  `file_id` int(11) DEFAULT NULL,
  `width` int(11) NOT NULL COMMENT 'la largeur de l''image',
  `height` int(11) NOT NULL COMMENT 'la hauteur de l''image',
  `ratio` int(11) NOT NULL COMMENT 'le ratio des dimensions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='enregistre toutes les images uploadées sur la plateforme';

-- --------------------------------------------------------

--
-- Structure de la table `language`
--

CREATE TABLE `language` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `movie_nbr` int(11) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `language`
--

INSERT INTO `language` (`id`, `name`, `slug`, `movie_nbr`, `create_at`) VALUES
(1, 'Français', 'francais', 5, '2018-06-29 18:05:18'),
(2, 'Anglais', 'anglais', 4, '2018-06-29 18:05:18'),
(3, 'Version Originale', 'version-originale', 0, '2018-08-09 00:00:00'),
(4, 'Darija', 'darija', 0, '2018-08-09 00:00:00'),
(5, 'VOST Français', 'vost-francais', 0, '2018-08-09 00:00:00'),
(6, 'VOST Anglais', 'vost-anglais', 0, '2018-08-09 00:00:00'),
(7, 'Version Darija doublée', 'version-darija-doublee', 0, '2018-08-09 00:00:00'),
(8, 'VOST Portugais', 'vost-portugais', 0, '2018-08-09 00:00:00'),
(9, 'Version Originale doublée Français', 'version-originale-doublee-francais', 0, '2018-08-09 00:00:00'),
(10, 'Version Originale doublée Anglais', 'version-originale-doublee-anglais', 0, '2018-08-09 00:00:00');

-- --------------------------------------------------------

--
-- Structure de la table `metadata`
--

CREATE TABLE `metadata` (
  `id` int(11) NOT NULL,
  `file` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le nom du fichier uploadé',
  `size` int(11) DEFAULT NULL COMMENT 'la taille du fichier uploadé',
  `status` enum('ban','pre-moderate','approved') COLLATE utf8_unicode_ci DEFAULT NULL,
  `moderate_at` datetime DEFAULT NULL COMMENT 'la date de moderation',
  `create_at` datetime NOT NULL COMMENT 'la date de l''upload'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `movie`
--

CREATE TABLE `movie` (
  `id` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `original_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `synopsis` longtext COLLATE utf8_unicode_ci,
  `tagline` longtext COLLATE utf8_unicode_ci,
  `logline` longtext COLLATE utf8_unicode_ci,
  `in_theather` tinyint(1) DEFAULT NULL COMMENT 'valide si un programme est à l''affiche ou non',
  `has_exclusivity` tinyint(1) DEFAULT NULL COMMENT 'marque un movie comme etant à la une',
  `format` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'enregistre le format du film',
  `year_start` date DEFAULT NULL COMMENT 'debut de l''année de production du film',
  `year_end` date DEFAULT NULL COMMENT 'fin de l''année de production du film',
  `mention` enum('HD','SD','4k','2k') COLLATE utf8_unicode_ci DEFAULT NULL,
  `cover_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'stock l''image de couverture du programme',
  `landscape_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'stock la vignette en paysage du programme',
  `portrait_img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'stock la vignette en portrait du programme',
  `trailer` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'le lien du trailer du programme',
  `episode_1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'le lien de l''episode 1 du programme',
  `episode_2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'le lien de l''episode 2 du programme',
  `episode_3` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'le lien de l''episode 3 du programme',
  `is_published` tinyint(1) NOT NULL COMMENT 'l''etat de publication du programme',
  `create_at` datetime DEFAULT NULL,
  `update_at` datetime DEFAULT NULL COMMENT 'date à laquelle le programme est modifié',
  `published_at` datetime DEFAULT NULL COMMENT 'date à laquelle le programme est marqué comme publié',
  `reward` longtext COLLATE utf8_unicode_ci COMMENT 'enregistre les recompenses obtenues du movie',
  `award` longtext COLLATE utf8_unicode_ci COMMENT 'enregistre les prix et les nominations du movie',
  `audience` longtext COLLATE utf8_unicode_ci COMMENT 'enregistre les audiences du movie',
  `insert_mode` enum('meta','meta-webmaster','meta-catalog','admin-form') COLLATE utf8_unicode_ci DEFAULT NULL,
  `in_workflow_at` datetime DEFAULT NULL COMMENT 'date à laquelle le programme est marqué comme etant en workflow',
  `desactivated_at` datetime DEFAULT NULL COMMENT 'date à laquelle le programme est marqué comme désactivé',
  `rejected_at` datetime DEFAULT NULL COMMENT 'date à laquelle le programme est marqué comme rejeté',
  `approved_at` datetime DEFAULT NULL COMMENT 'date à laquelle le programme est marqué comme approuvé',
  `state` enum('rejected','pre-moderate','approved','workflow','deactivated') COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `movie`
--

INSERT INTO `movie` (`id`, `category_id`, `language_id`, `name`, `slug`, `original_name`, `synopsis`, `tagline`, `logline`, `in_theather`, `has_exclusivity`, `format`, `year_start`, `year_end`, `mention`, `cover_img`, `landscape_img`, `portrait_img`, `trailer`, `episode_1`, `episode_2`, `episode_3`, `is_published`, `create_at`, `update_at`, `published_at`, `reward`, `award`, `audience`, `insert_mode`, `in_workflow_at`, `desactivated_at`, `rejected_at`, `approved_at`, `state`) VALUES
(98, 4, NULL, 'Brouteur.com', 'brouteur-com', 'Brouteur.com', '', NULL, NULL, 1, 0, '26x26\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'pre-moderate'),
(99, 4, NULL, 'INNER BEAUTY', 'inner-beauty', 'INNER BEAUTY', NULL, NULL, NULL, 0, 0, '', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(100, 6, NULL, 'CHAMPS 12', 'champs-12', 'CHAMPS 12', 'When they were still young, Charlotte, 12 years old, had been humiliated by Gonzalo, a handsome 15 years old who dreams of becoming a professional soccer player. During a match, he accomplished a challenge by kissing a ugly girl that seems to be Charlotte after failing to score a goal as conclude in the bet with his friend. Now she is 18 years and she got back to the town after living with her mother in New-York. The young lady is still driving by this past humiliation; she decides that the time has come to take revenge on the boy that once shamed her. The day Charlotte arrives at the soccer club as the new owner, Gonzalo is immediately struck by her, unaware that she is the chubby girl he once humiliated. They fight relentlessly unwilling to acknowledge their growing feeling and the passion they share. Things begin to change when Charlotte\'s father is forced to sell the club, which has become, under Charlotte\'s rule, a refuge for the fortunate kids of the neighborhood. The new owners want to turn the club into a profitable business, at any cost, and Charlotte and Gonzalo will now have to join hands and face them head on. By fighting a common enemy, they will gradually learn to appreciate and love each other, but most importantly, let go of the past.An exciting telenovelas, filled with love, friendship, music and dance that is sure to make you feel alive kicking!', NULL, NULL, 1, 0, '120 x 45\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(101, 2, NULL, 'THE DAY GOD WALKED AWAY', 'the-day-god-walked-away', 'Le jour ou Dieu est parti en voyage ', 'A woman finds herself trapped in the midst of a brutal civil war with no way out in this drama inspired by actual events. Tensions between Tutsis and Hutus, the two principal ethnic groups in Rwanda, had been simmering for years when they finally exploded in the spring of 1994; the nation\'s president, Juvenal Habyarimana, was a Hutu who died after his plane was attacked with rockets during a landing, and when word spread that a group of radical Tutsis were responsible, Hutus went on a rampage, as 800,000 Rwandans (mostly Tutsis) were massacred within four months. Jacqueline (Ruth Nirere) was a young Tutsi woman who worked for a family of Belgian émigrés in Kigali. She was in their home when the fighting first broke out, and as roving bands of Hutus made their way into the neighborhood, the family fled and Jacqueline was forced to take shelter in the attic. As waves of bloody violence swept through Kigali and the rest of Rwanda, Jacqueline was trapped in the attic as she watched civilization break down into madness when she dared to look out the window for the next 100 days.', NULL, NULL, 0, 0, '1 x 94\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(102, 2, NULL, 'LA COULEUR DES SENTIMENTS', 'la-couleur-des-sentiments', 'THE HELP', 'Dans une ville du Mississippi, Jackson, au début des années 60, une jeune femme blanche, Skeeter, qui vient juste de terminer ses études, souhaite devenir journaliste. Elle décide alors de s\'intéresser aux conditions de vie des femmes de ménage noires chargées Ã  cette époque Ã  la fois de la maison et de l\'éducation des enfants. Dans le cadre de ce projet, elle rencontre deux domestiques, Aibileen, plutét docile, et Minny, un peu plus rebelle, qui, en prenant de gros risques, vont persuader d\'autres domestiques de raconter leur histoire. Elles acceptent de témoigner de leur existence, permettant la rédaction d\'un livre qui deviendra vite un best-seller. De cette alliance improbable naÃ®tra une solidarité extraordinaire, Skeeter devra alors rompre avec ses amies d\'enfance enserrées dans leur vie de femme au foyer du sud des Ã‰tats-Unis. Ã€ travers leur engagement, chacune va trouver le courage de bouleverser l\'ordre établi, et d\'affronter tous les habitants de la ville qui refusent le vent du changement.', NULL, NULL, 0, 0, '1 x 146\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(103, 4, NULL, 'LA VESTE', 'la-veste', 'LA VESTE', 'Angèle est une jeune fille belle, studieuse et intelligente, issue d\'une famille pauvre. Ses parents Ebodé et Thérèse, avides d\'argent, espèrent donner leur fille en mariage afin de renflouer leurs poches. Anicet, le jeune cueilleur de vin de palme du village semble être le parfait candidat. A la grande joie d\'Anicet, qui secrètement admirait Angèle. Tout semblait marcher pour Anicet, jusqu\'à  ce qu\'Anatole tombe lui aussi sous le charme d\'Angèle. Ce prétendu homme d\'affaires vient chambouler les plans du jeune cueilleur de vin de palme et bercer la famille d\'Angèle de belles paroles, et de douces illusions. Si l\'habit ne fait pas le moine, qui d\'Anicet ou d\'Anatole remportera le droit d\'épouser la belle Angèle? La Veste raconte l\'histoire d\'une société qui à cause de la pauvreté a perdu sa vertu au détriment de l\'intérêt.', NULL, NULL, 0, 0, '13 x 26 \'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(104, 4, NULL, 'RUSH', 'rush', 'RUSH', 'RUSH is an exciting, inspiring television series and moreover a transmedia storytelling &amp; entertainment experience AND empowering a new generation of young African women to Live the Fabulous Life, showcasing and taking them into a cosmopolitan world of opportunities.', NULL, NULL, 0, 0, '13 x 26 \'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(105, 4, NULL, 'FASHE', 'fashe', 'FASHE', 'FASHE est une agence de mode dirigée de main de maitre par l\'ambitieuse Maya. Cette série est une incursion dans le quotidien de cette dynamique agence. Maya souhaite voir son agence prospérer et fait de son mieux pour trouver les fonds et les marchés qui lui permettront d\'accroitre et pérenniser son activité. La jeune dame met également un point d\'honneur à  créer un environnement de travail saint et motivant pour ses mannequins. Malheureusement, la gestion d\'une agence de mode n\'est pas aussi facile que cela pourrait paraître. Maya doit inévitablement faire face aux coups bas et autres rivalités entre les mannequins avides d\'argents et de gloire. A cela, il faut rajouter les tumultueuses histoires d\'amour et la rude concurrence du secteur. L\'arrivée d\'une nouvelle recrue insufflera une nouvelle dynamique et la vie de l\'agence en sera profondément bouleversée.', NULL, NULL, 1, 0, '26 x 26\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(106, 8, NULL, 'STYLE TIPS', 'style-tips', 'STYLE TIPS', 'Elles ont entre 18 et 40 ans et vivent dans les grandes métropoles africaines. Toujours connectées aux nouvelles technologies de l\'information et de la communication, les femmes africaines ne veulent plus rien rater de l\'évolution de la société, encore moins être en marge de l\'effervescence des tendances actuelles de la mode. The Style Tips, un condensé de 3 minutes de conseils en mode et maquillage destiné à  la femme moderne de tout âge, et de toute origine se propose de leur donner des conseils simples mais pratiques pour rester « Trendy». La série répond à  une question simple : "comment avoir du style au quotidien?" La série se subdivise en trois grands chapitres : 15 Fashion Fillers / 15 Make-up Fillers / 15 Do It yourself. MesdamesÂ ! Avos pinceaux !', NULL, NULL, 0, 0, '45 x 3\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(107, 4, NULL, 'ADAMS APPLES', 'adams-apples', 'ADAMS APPLES', 'Adams Apples is a 10-part movie series that follows the lives of the four Adams women (the widowed, ex-diplomat\'s wife and her three 30-something year old daughters). These four women work through family struggles, life and personal battles to achieve happiness and success in their lives.What they discover through their various trials and tribulations is that everything is far from easy. Especially in a fast-changing 21st Century Ghana. Here, love is often hard to come by. Victory is not always achieved by those who work hard. And marriage is not always what it is cracked up to be.Will the Adams women be able to find what they are looking for, from life and from each other? Watch this heart warming movie series to find out!In Adams Apples Chapter 1, meet the Adams women for the first time in what will be an exciting and unforgettable journey.', NULL, NULL, 1, 0, '65 x 45\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(108, 6, NULL, 'Juana\'s Miracle', 'juanas-miracle', 'Juana la Virgen', '"Juana\'s Miracle" is the story of a young girl named Juana, whose life will change drastically when she gets pregnant without having sexual intercourse, and Mauricio, a man obsessed of becoming a father at any cost. Both of them will have their lives attached to one another but without being separated by lies. This is a telenovela where the value of woman goes beyond her virginity ...Juana is afraid of love. The failures of her family have made her more distrusting and apprehensive when it comes to love. But one day she starts to feel physical changes within her bodyâ€¦ When she visits the doctor, he tells her some astonishing news: Juana is pregnant. But how, Juana is a virgin ...The answer for more mystic than it sounds, it is easy to explain: By error, she was submitted to an artificial insemination that was not meant for her. The delicate and incorrigible error will make an irresponsible doctor to be silent and never speak of his error by eliminating and hiding out all evidence. As the atmosphere is filled with confusion, in Juana\'s womb grows Mauricio de la Vega\'s last fertile seed of life, who wants to be a father at any cost. Juana will have to stand the rejection and the fanatics of others who see her as a form of reincarnation of the Virgin Mary. When Mauricio finds out that a mysterious woman is carrying his child, he begins a frustrating search and when both meet, due to their professions, they will see their lives connected but not before enduring heartaches.', NULL, NULL, 0, 0, '153 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(109, 2, NULL, 'DEAR MOTHER', 'dear-mother', 'DEAR MOTHER', '', NULL, NULL, 1, 0, '1 x 60\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(110, 2, NULL, 'FREAKY FRIDAY', 'freaky-friday', 'DANS LA PEAU DE MA MERE', 'Le docteur Tess Coleman et sa fille Anna ne se comprennent plus : les vêtements qu\'elles portent, les personnes qu\'elles fréquentent, les musiques qu\'elles écoutent, tout les oppose ! Ana \'accepte pas le nouveau fiancé de sa mère et Tess ne supporte plus la musique que joue sa fille. Un soir, à  la veille du remariage de Tess et d\'un concert donné par Anna, leur rancune éclate. Mais un sortilège chinois va bouleverser leur vie... Le lendemain, Tess se retrouve dans la peau de sa fille alors qu\'Anna est dans le corps de sa mère ! Voulant cacher à  tout prix cette situation à  leur entourage, elles vont devoir adopter le point de vue de celle qu\'elle ne comprenait plus... Mais le mariage et le concert approchent, et Anna et Tess vont tout mettre en oeuvre pour rompre le sortilège. Un film très attachant et dréle qui réconciliera mères et filles.', NULL, NULL, 0, 0, '1 x 97\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(111, 4, NULL, 'Les concessions', 'les-concessions', 'Les concessions', 'A series centers around four stories. The main talks about the opposition Sory, a rich business man impose to his seventy years old mother when he decided to marry a Christian girl as second wife. Besides, there are some stunning stories like Isaac, son of Boniface falling in love with his Métis half-sister or Oumou who recovers her mind by the coming of her first husband. The personages of these stories are linked by friendship, business affairs and secrets.', NULL, NULL, 0, 0, '52 x 26\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(112, 6, NULL, 'AU COEUR DU PECHE', 'au-coeur-du-peche', 'SHADES OF SIN', 'Twin brothers are separated in childhood and they grow up without knowing about each other. As adults, they suffer an accident in the same place, at the same time. One disappears in the ocean and the other decides to assume his identity. Years later, as he finds out he has a son and that the woman he loves did not cheat on him; he decides to reclaim his true identity.', NULL, NULL, 1, 0, '160 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(113, 4, NULL, 'LES CHOCOS EN VACANCES', 'les-chocos-en-vacances', 'LES CHOCOS EN VACANCES', 'Edan n\'a pas mis les pieds à  Abidjan depuis trois bonnes années. Maintenant qu\'il y est pour les vacances, il compte bien retrouver ses deux amis d\'enfance et s\'éclater au maximum ! Composée de Chapat, l\'intello timide et Ahmed le fàªtard bling-bling, la bande s\'est récemment agrandie d\'un membre : Capucine, métisse aussi jolie que vénale. Ensemble, les quatre amis choco enchaineront virées nocturnes, plans drague et 400 coups mais très vite, les vacances prendront une tournure inattendue.Edan sera surpris d\'apprendre que ces « vacances » sont en réalité un retour forcé au bercail. Ses parents ont perdu leur fortune en Europe et doivent réduire leur train de vie. Ils vendront màªme leur belle villa abidjanaise pour emménager avec Edan dans un quartier populaire. Pour le jeune homme nourri au luxe, c\'est un coup dur et il a plus que jamais besoin du soutien de ses potes. Mais leur amitié résistera-t-elle à  ce changement de statut social ?Pour Capucine, les vacances seront marquées par tout un tas d\'amourettes aussi cocasses les unes que les autres. La belle est en effet en quàªte de l\'oiseau rare : un footballeur, une star du show-biz ou un milliardaire qui saura lui donner ce qu\'elle mérite c\'est-à -dire un max de cash ! De guerre lasse, elle décide de se poser avec Boris, un bon parti qui lui court après depuis des lustres. Cupidon frappe et Capucine tombe amoureuse mais de la mauvaise personne. Elle s\'éprend de Boni, le « bon petit » de Boris. Boni est un étudiant sans le sou et veut faire de Capucine la « femme africaine modèle ». Pour la jeune femme, troquer ses minijupes contre des complets pagnes est la pire des tortures. Et c\'est sans compter la colère de Boris qui ne supportera pas cette nième trahison.Au gré des aventures et mésaventures des chocos, Chapat sera amené à  surmonter sa timidité, Ahmed aura des démàªlés avec la police et tous les quatre feront la connaissance du duo Soum et Bobby. Ces deux mecs nouchi des quartiers populaires, gaou mais irréfutablement débrouillards sont tout le contraire des chocos à  qui ils veulent pourtant ressembler.', NULL, NULL, 0, 0, '20 x 26\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(114, 6, NULL, 'MADEMOISELLE', 'mademoiselle', 'LITTLE MISSY', 'Mademoiselle raconte l\'histoire de cette jeune femme héroà¯que qui fait partie de cette génération d\'hommes et de femmes qui se sont battues pour faire abolir l\'esclave avec leurs idées de liberté et d\'égalité pour tous. Après de brillantes études à  la capitale, Mademoiselle, la fille du baron de Araruna et son ami Rodolfo, issu d\'une riche famille d\'avocats, retournent chez eux au moment même à la campagne pour l\'abolition de l\'esclavage fait rage. Cependant le baron, son père n\'est pas prêt de renoncer à  ses privilèges et fait pression sur la population afin d\'étouffer toutes velléités d\'indépendance. Mais il était loin d\'imaginer que sa propre fille ; son propre sang serait celle là  même qui deviendra son plus farouche adversaire. Dans son combat, Mademoiselle recevra un soutien de taille ; celui de Rodolfo, son ami de tous les jours dont elle ignorait qu\'il était un activiste chevronné. Ensemble, ils gagneront la bataille, celle de voir tomber les barrières entre les classes et celle de pouvoir s\'aimer librement ...', NULL, NULL, 0, 0, '280x26\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(115, 4, NULL, 'HALF & HALF', 'half-half', 'HALF & HALF', 'Mona et Dee-Dee \'ont apparemment qu\'une chose en commun : leur père !', NULL, NULL, 0, 0, '69 x 26\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(116, 5, NULL, 'La Princesse et la grenouille', 'la-princesse-et-la-grenouille', 'The Princess and the Frog', 'Un conte qui se déroule à  la Nouvelle-Orléans, dans le légendaire quartier franà§ais, à vit une jeune fille nommée Tiana.', NULL, NULL, 0, 0, '1 x 97\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(117, 6, NULL, 'CARIBBEAN FLOWER', 'caribbean-flower', 'FLOR DO CARIBE', 'The exhilarating story of love and adventure of Caribbean Flower is set in the astonishing and fictitiousbeach town Vila dos Ventos, amid sand dunes, salt works and stunning beaches. Cassiano (Henri Castelli),an air force fighter pilot and squadron leader, and Ester (Grazi Massafera), a tourist guide who provides localdune buggy rides, falls madly in love at a young age. Although their love continues to grow throughout theyears, their lives change completely after a treacherous plot is carried out by Alberto (Igor Rickli), thecouple\'s childhood friend and heir to the wealthy Albuquerque family fortune. The villain secretlyand obsessively nurtures his love for the young woman and wishes to get rid of Cassiano at anycost. Upon the request of his grandfather Dionà­sio (Sérgio Mamberti), Alberto assumes controlof the Albuquerque Conglomerate, and sets a trap for Cassiano. He asks the pilot to fly to theCaribbean to deliver a shipment of diamonds to an important buyer. The trip will supposedlyhelp solve labor issues facing many local salt work employees, including Cassiano\'s father.In reality, the shipment is filled with salt rocks that resemble diamonds and the buyer is thepowerful Dom Rafael (César Troncoso), a violent gem dealer. Cassiano suddenly disappearsand is presumed dead but remains alive, contrary to what Dom Rafael tells Alberto andEster. In fact, Cassiano\'s life is spared and he is maintained in captivity for years. Albertotakes the opportunity to comfort Ester. Upon returning from a search and rescue operationin the Caribbean, she discovers she is bearing Cassiano\'s child. Seeing Alberto as a closefriend and practically a father to her son, Ester gives in to his advances and the two marry.At last, Alberto fulfills his evil plan. Over the yearsAlberto becomes a good father to little Samuca andthe daughter he has with Ester, Laurinha.', NULL, NULL, 1, 0, '120 x 90\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(118, 6, NULL, 'JACOB\'S CROSS', 'jacobs-cross', 'JACOB\'S CROSS', 'Série évènement de 2010 ; Jacob\'s Cross force à  un nouveau regard sur l\'Afrique. Loin des clichés misérabilistes ; elle nous offre la vision d\'une Afrique moderne et conquérante.Voici l\'histoire d\'un homme qui a pour ambition de bâtir avec des capitaux exclusivement africains, un empire financier aussi puissant que les empires occidentaux qui gouvernent le monde moderne. L\'histoire se déroule en Afrique du Sud avec en toile de fond cette nouvelle classe émergente qui préside aux destinées du pays depuis la fin de l\'apartheid.Jacob Makhubu, un jeune et brillant homme d\'affaires, est sur le point d\'obtenir l\'un des plus gros contrats gouvernementaux portant sur la recherche d\'une nouvelle source d\'énergie. Jacob est séduisant et tout lui sourit dans la vie ; il est le fils d\'une célèbre chanteuse de jazz et d\'un héros défunt de la lutte anti-apartheid. Il a fait de brillantes études dans de grandes universités anglo-saxonnes et vient tout juste de rentrer au pays. Jacob se voit offrir une chance unique lorsqu\'un consortium nigérian lui offre le financement dont il a besoin à  la condition qu\'il accepte d\'en être le dirigeant. Même si Jacob est séduit à  l\'idée de se trouver à  la tête de l\'une des compagnies les plus puissantes et prestigieuses du continent ; il n\'en demeure pas moins qu\'il craint avant tout de perdre son indépendance. Il se rend donc à  Lagos pour rencontrer le chef Abayomi fondateur de l\'empire du même nom. Au lieu de parler business, le patriarche Abayomi révèle à  Jacob être son père et lui offre d\'être son héritier à  la tête de son empire.Ce lourd héritage entraînera Jacob dans une quête épique à il aura à  affronter aussi bien des membres de sa nouvelle famille que de puissants adversaires tapis dans l\'ombre.Diffusée sur le Câble par France Télévision et sur la chaîne à  péage Canal+ ; vivement saluée par le célèbre magazine Télérama, Jacob\'s Cross a remporté les suffrages unanimes de tous les spectateurs de France et du continent Africain.', NULL, NULL, 0, 0, 'S1 12 x 52\' / S2 13 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(119, 6, NULL, 'INDIA - A LOVE STORY', 'india-a-love-story', 'CAMINHO DAS INDIAS', 'A groundbreaking TV production by world-renowned author Gl?ria Perez (The Clone), \'India-A Love Story\' is a contemporary story set in Brazil and India, a thrilling tale exploring the clash between different cultures and traditions. The main plot centers on the story of Raj, a young and traveled Indian executive from a caste of merchants divided between Western and Eastern values, and Maya, a modern, studied and working Indian girl from the same caste who has always believed she would choose her husband. Raj is in love with Duda, a modern and independent Brazilian girl who suffers with the prejudice of Raj?s family. Maya is in love with Bahuan, an impetuous and well-educated Indian dalit whose lack of caste turns him into a social pariah. Bahuan can\'t forget the humiliations he lived in his childhood for being considered impure for the Hindu society. Bound by tradition, Raj and Maya are forced to deny these loves, considered forbidden. Hence, Raj and Maya stories collide: their families negotiate their marriage and they are forced to leave these impossible loves behind. Will they be able to build a new real love relation? Will they be able to keep secrets from their past from coming to light and destroying their newfound feelings? Filled with swirling color, music and movement, \'India - A Love Story\' is the winner of 2009 International Emmy Awards for Best Telenovela. A spellbinding tale that grips the audience from beginning to end. Different traditions and cultures collide in a fascinating love story. India - A love story.', NULL, NULL, 0, 0, '160 x 52\' ', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(120, 6, NULL, 'WINDECK', 'windeck', 'WINDECK', 'In this exciting Angolan telenovela WINDECK, the colorful characters lend to this exhilarating telenovela a tenderly redemptive afterimage. WINDECK is more than just another telenovela about seduction and betrayal, it is instead an elegant and atmospheric fiction about survival and redemption. Constantly engaging and witty, the story centers around DIVO, a famous Angolan advertising agency. Beautiful Victoria, an innocent young lady fresh out of Mexico seeks out fame and fortune and is willing to stop at nothing to realize her dream. For her, life is nothing more than a game. She is ruthlessly ambitious, her seductive walk, murderous reptilian glare and stunning beauty are used with deadly effect. She is on a mission to seduce Kiluanji...but alas, things never go as planned...The WINDECK plot veers into a passionate examination of the meaning of love and life, and is a celebration of the color, essence, vibrancy and vitality of Angolan cultureand debate on a plethora of African socio-economic issues.', NULL, NULL, 0, 0, '105 x 45\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(121, 4, NULL, 'APHASIE LA REVOLTE DE DANTRA', 'aphasie-la-revolte-de-dantra', 'APHASIE', 'Thriller politique qui traite de la question du terrorisme sur fond de complots d\'états,de manipulations et d\'enquêtes policières.Au soir de l\'indépendance, alors qu\'il s\'offrait une sortie non officielle, le Président Jean Regnard disparait dans une embuscade. Au même moment, le pays est la cible d\'un vaste complot terroriste.L\'agent Karl GAUDENCE, connu pour ses méthodes controversées et l\'Agence de contre-espionnage Ivoirienne la « D.I.A » se lancent à  sa recherche. Ils tentent par la même occasion de déjouer des attaques imminentes.', NULL, NULL, 1, 0, '26 x 26\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(122, 2, NULL, 'FELICITE', 'felicite', 'FELICITE', 'Félicité sings and the word stops turning. This proud selfmade woman will be forced to put aside her principles to find in a short period of time the money for her son\'s surgery. she goes on a frantic search through the streets of Kinshasa when her path crosses that of Tabu.', NULL, NULL, 0, 0, '1 x 103\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(123, 6, NULL, 'TOTAL DREAMER', 'total-dreamer', 'TOTAL DREAMER', 'After escaping sexual harassment from her own drunken stepfather, Eliza runs away from home with the help of her mother, Gilda to try her luck in the big city. Her ultimate dream is to provide a better life for her mother and siblings. When she gets robbed on her very first day there, Eliza ends up living in the streets - where she meets Jonatas, a charismatic guy who is in charge of parking spaces and who sells candy by traffic lights. Eliza starts selling flowers to make a living with his help and they both develop a true friendship destined to become the most beautiful love story.', NULL, NULL, 0, 0, '130 x 48\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(124, 2, NULL, 'THE BACK UP PLAN', 'the-back-up-plan', 'Le plan B', 'Lassée d\'attendre un hypothétique Prince Charmant, Zoe a décidé de faire un bébé toute seule. Le jour même de l\'insémination, elle rencontre Stan, qui pourrait bien être l\'homme dont elle rêvait. Zoe se rend vite compte que démarrer à  la fois une grossesse et une histoire d\'amour est plutét compliqué, surtout lorsque l\'homme n\'est pas le père de l\'enfant, et qu\'en plus il ne sait même pas qu\'elle est enceinte. De son cété, Stan a bien du mal à  comprendre Zoe, qui tente de cacher les premiers signes de sa grossesse. Ils ne savent rien l\'un de l\'autre, chacun a ses propres doutes, le bébé sera bientét là  et la vie s\'acharne à  les placer dans les situations les plus impossibles. Tout le monde peut tomber amoureux, se marier et avoir un bébé. Mais prendre les choses à  l\'envers et commencer par le bébé, c\'est une autre aventure.', NULL, NULL, 0, 0, '1 x 107\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(125, 4, NULL, 'SCANDAL', 'scandal', 'SCANDAL', 'Olivia Pope est responsable de la communication et de l\'image de hautes personnalités politiques américaines. Son expertise est la résolution de crise. Après avoir été parmi les proches collaborateurs du Candidat Fitz pendant sa campagne présidentielle, et permis sa victoire; la jeune femme décide de quitter la nouvelle équipe de la Maison Blanche pour fonder son propre cabinet conseil. Son travail ? Régler les problèmes de ses clients, souvent des personnalités publiques, dont la carrière, voire la vie est mise en danger par un scandale sur le point d\'éclater. Entourée de ses « gladiateurs », une équipe ultra pointue de juristes, enquêteurs, hackers / tueurs, Olivia trouve une issue à  tout problème... C\'est pour à§a que le président Fitz fait appel à  elle lorsqu\'une de ses assistantes fait courir le bruit qu\'ils couchent ensemble. Olivia tentera tout pour gérer ce scandale, aux tentacules et aux répercussions bien plus désastreuses qu\'elle ne le pense. Le personnage d\'Olivia Pope est inspiré d\'une personnalité réelle, Judy Smith, qui a travaillé à  la Maison Blanche sous l\'administration de George Bush en tant que responsable de la gestion des crises', NULL, NULL, 0, 0, '29 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(126, 4, NULL, 'REVENGE', 'revenge', 'REVENGE', 'Enfant, Amanda Clark vivait dans la petite ville paisible des Hamptons, avant de voir son existence brisée. En effet, Quinze ans plus tét, son père fut accusé à  tort du financement d\'un réseau terroriste et envoyé en prison jetant ainsi le déshonneur sur la famille Clark. Il meurt quelques temps après. Après une absence de plusieurs années, la jeune femme retourne vivre dans les Hamptons sous le pseudonyme d\'Emily Thorne avec la ferme intention de détruire ceux qui ont brisé son innocence et gâché la vie de son père.', NULL, NULL, 0, 0, 'S1 22 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(127, 4, NULL, 'BUNHEADS', 'bunheads', 'BUNHEADS', 'Pour le meilleur et pour le pire, Michelle Simms est coincée dans la petite ville californienne de Paradise. En 24 heures, cette trentenaire a complètement changé de vie : danseuse à  Las Vegas, faute d\'une carrière à  Broadway tant espérée, elle a accepté sur un coup de tête d\'épouser Hubbell, l\'un de ses gentils fans. Mais le lendemain, celui-ci trouve la mort dans un accident de voiture ! Malgré son indépendance, son insolence et son instabilité chronique, Michelle doit désormais gérer l\'école de danse dont elle a hérité de son mari. Pour ne rien simplifier, c\'est la mère de Hubbell, Fanny, qui y enseigne le ballet aux adolescentes de Paradise. Parmi ces élèves, Sasha, Ginny, Boo et Melanie vont trouver une sorte de grande sÅ“ur en Michelle. Avec Bunheads, Amy Sherman-Palladino dresse avec humour, le portrait de troisgénérations de femmes.', NULL, NULL, 1, 0, '18 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(128, 4, NULL, 'THE GOOD WIFE', 'the-good-wife', 'THE GOOD WIFE', 'L\'épouse d\'un homme politique voit sa vie bouleversée par l\'incarcération de son mari à  la suite d\'un scandale et d\'une affaire de corruption largement relayés par les médias. Dépassant la trahison et l\'humiliation publique, Alicia Florrick décide reprendre sa carrière d\'avocate après une pause de 13 ans loin des tribunaux. Elle rejoint un ami de longue date au sein d\'un prestigieux cabinet de Chicago. Très vite, Alicia réalise que la compétition va être rude avec de jeunes recrues ambitieuses et déterminées. Mais au moins pour une fois, elle est prête à  prendre en main sa propre destinée et détruire son image d\'épouse modèle.', NULL, NULL, 0, 0, 'S1 23 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(129, 6, NULL, 'CORAZON PARTIDO', 'corazon-partido', 'COEUR BRISE', 'ura Echarri est une belle jeune femme de 24 ans. Photographe de renom, elle voyage à  travers tout le Mexique pour capturer des images. Alors qu\'elle finit une séance de photos, une jeune femme accouche sur la voie publique. Ce miracle réveille en Aura le douloureux souvenir de la raison de son exil. En effet, à  16 ans, Aura tombe enceinte. Elle ne sait pas qui est le père ; de German, son amoureux ou son frère Sergio qui l\'a violée. German et Sergio sont les fils de Rogelio Garza, le second mari de Fernanda la mère d\'Aura ; donc ses demi-frères. Si sa famille lui avait donné l\'opportunité d\'expliquer ce qui est arrivé, la jeune femme aurait moins souffert ; mais ce ne fut pas le casé Femme de caractère et de conviction, Virginia, la grande mère maternelle d\'Aura l\'expédie dans leur hacienda dès qu\'elle apprend que sa petite fille est enceinte. Elle laisse entendre à  tous qu\'Aura est allée étudier à  l\'étranger. En visite au ranch, Gregorio son grand-père, est horrifié de découvrir que sa femme y détient Aura. Dans sa tentative de soustraire Aura à  cet enfer, il est victime d\'un accident de voiture. Gregorio meurt et Ignacio le petit frère d\'Aura qui l\'accompagnait ; se retrouve paralytique.Traumatisée par cette tragédie, Aura accouche aussitét. Par méchanceté et vengeance, Virginia lui arrache son bébé et le donne en adoption.Quand Aura aide cette jeune femme à  accoucher sur le sol nu et qu\'elle comprend que cette dernière ne veut pas du bébé, et voit défiler devant ses yeux, sa propre histoire ? Elle décide alors de retourner chez elle à  Mexico pour rechercher son enfant et affronter sa famille. Adrian est mécanicien et possède un petit garage. Marié à  Nelly, il est le père adoptif d\'Esteban le fils d\'Aura. Le couple a du adopter, ne pouvant avoir d\'enfant. Mais très vite, l\'enfant qui devait renforcer leurs liens devient l\'otage du trop plein d\'amour de ses deux parents. C\'est alors qu\'Adrian rencontre Aura et en tombe amoureux?Lorsque Nelly découvre que son mari est amoureux d\'une autre femme, elle décide pour le retenir de se servir de son fils. Adrian sait qu\'Aura est à  la recherche de son fils mais se laisse convaincre par Virginia que l\'enfant en question était une fille et qu\'elle est morte à  la naissance. Peu de temps après, il apprend la vérité et se trouve partagé entre son amour pour Aura et la vérité qu\'il doit à  son fils. Quant à  Nelly, elle lutte pour garder l\'enfant qu\'elle a élevé et avec lequel elle a tissé des liens d\'un amour désespéré. Adrian se retrouve face à  un grand dilemme car quelque soit l\'issue, il en résultera un immense chagrin pour l\'une ou l\'autre femme ?', NULL, NULL, 1, 0, '90 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2017-08-21 01:59:51', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(130, 6, NULL, 'CAMA DE GATO', 'cama-de-gato', 'CAT\'S CRADLE', 'Imagine a strong and tender hearted woman, a confused man and a villain capable of everything to get money. We have the perfect love triangle to a classic love story. \'Cat\'s Cradle\' tells the tale of a man that hits rock bottom and manages to bounce back through true love. Gustavo, once a poor, kindhearted youngster, is now a successful entrepreneur in the perfume business, but has turned cruel, arrogant and miserable. Alcino, his best friend and partner, helped him achieve his present success. When he finds out that has a fatal disease and has a few months to live, he decides to play a prank on Gustavo to help him rediscover the decent man he once was and the joy of living he once had. Gustavo is married to Veronica, a rich, selfish, spoilt and ambitious woman who has never loved her husband. The prank played by Alcino takes an unexpected turn when Veronica, the story\'s great villain, interferes, manipulates the surprise, makes Gustavo lose almost everything, be mistaken for dead and accused of a crime.While trying to pick up the pieces of his life, Gustavo meets Rose, a simple, hard-working woman who raises four kids by herself with great spirit and optimism. Because of her good heart, she starts to help Gustavo and to put his life back together. Gradually, feelings sprout between the couple, leading our hero to rediscover his humanity through the hands of this newfound love. A contemporary and urban telenovela, \'Cat\'s Cradle\' blends suspense, twists, surprises, redemption and romance to produce a stirring story of love reborn. Cat\'s Cradle. An entrapment opens the doors to redemption.', NULL, NULL, 1, 0, '110 x 52\'', '2017-08-21', '2017-08-21', NULL, NULL, NULL, NULL, 'https://vimeo.com/205265379', 'https://vimeo.com/205265379', 'https://vimeo.com/205265379', 'https://vimeo.com/205265379', 1, '2017-08-21 01:59:51', '2018-08-08 10:30:00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(131, 6, NULL, 'PASSIONE', 'passione', 'PASSIONE', 'Starring a host of TV Globo\'s most renowned actors, the telenovela \'Passione\' centers around family relationships in Brazil and Italy and the secrets pertaining the characters. Fifty-five years before the story begins, Beth, pregnant by another man, meets and marries Eugene Gouveia, who initially pledges to raise the child as his own. Throughout her life, Beth believed her son had died at birth, but Eugene, on his death bed, reveals that he could not bear the thought of raising another man\'s child and had in fact given him away to an Italian couple, together with a large sum of money, to be raised in Italy. Meanwhile, in Tuscany, Toto Mattoli, a widowed farmer, leads a quiet life with his elder sister, his children and his grandson. He is content and lives in blissful ignorance of his true heritage. An astonished Beth, the matriarch of a large business empire, learns that she was married for years with a liar. Unsure of how to tell her own family about the existence of this new heir, and not knowing where he is, she sets her mind to finding him and granting him his rights to the family estate. While pondering what to do, Beth confides in Claire, Eugene\'s nurse, who was present at the time of his confession. Claire agrees to secrecy, but sees the chance of a lifetime. She plots with her lover Fred to win over the heart of Beth\'s Italian son and seize his inheritance. After several twists and turns, Toto falls passionately in love with Claire and eventually discovers that his real mother is alive in Brazil, where a new life awaits him. The revelation will cause a series of entanglements and the revelation of new secrets, and nothing will ever be the same for the Gouveia and Mattoli families.Passione. Every family has its secrets.', NULL, NULL, 1, 0, '160 x 52\'', '2017-08-21', '2017-08-21', NULL, 'c4fd7c77e6c8b5d41229c7d38728a18b.jpeg', 'd560dbf635e2ba9c576022870f0ccb69.jpeg', '92a5c0868189d8053746ede15d13084c.jpeg', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 1, '2017-08-21 01:59:51', '2018-08-03 17:34:20', '2018-08-03 16:58:21', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(132, 6, 29, 'SHREE', 'shree', 'SHREE', 'This is a story of a Gujrati family following their traditions in a place called Jankpur. Mean while another family is busy trying to find a suitable girl for the youngest son in their family. But for the past 12 relations has been canceled and something is trying to stop them. A spirit is in love with the youngest son whose name is Hari. The youngest girl in Janakpur, her name is Shree. Hari once had some work to do. So he went to Janakpur to build a mall there. The first time he met Shree, he fell in love with her. They both got married and the evil spirit had some plans to kick Shree out of the house. Can Shree do anything to fight the evil spirit and save her family?', NULL, NULL, 1, 0, '187 x 26\'', '2017-08-21', '2017-08-21', NULL, '058fa35a08a4b73d6583983caeb90fd9.jpeg', 'df7dabb521a39afa5e9bb93f5ad14c1c.jpeg', 'aed1e5f50a981a563c3177bf3cf480d6.jpeg', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 1, '2017-08-21 01:59:51', '2018-08-09 12:51:57', '2018-08-03 17:01:33', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(133, 6, 28, 'A FAVORITA', 'a-favorita', 'THE FAVORITE', 'Flora and Donatella were two friends bonded by their love of music, but whose passion for the same man separated them forever. Donatella was Marcelo\'s wife; Flora, his lover and murderer - a crime which cost her freedom and the custody of her daughter Lara, born out of that relationship and raised by Donatella. Now, history repeats itself, only this time their quarrel is not only over the same man but for Lara\'s love. Torn between two mothers, the girl doesn\'t know that Flora\'s dirty, scheming ambition is not to draw her closer, but to keep her away from her longtime rival - plus snatch the inheritance of her former lover. The theme of rivalry - Flora\'s bitter jealousy of the prettier and more talented Donatella permeates this provocative story and makes vengeance a ruleless game.', 'Un court métrage sur la foire aux vins naturels à Villa Favorita by Vinnatur.', 'Un court métrage sur la foire aux vins naturels à Villa Favorita by Vinnatur.', 1, 0, '150 x 52\'', '2017-08-21', '2017-08-21', NULL, '928b44677c5a5b6f5d068d2637c597ac.jpeg', '899e131c8a4bb4e13a0b17a381ee83a9.jpeg', 'e018d216f89e03109b7d55d18ad8e515.jpeg', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 'https://vimeo.com/283038709/6d3e4565db', 1, '2017-08-21 01:59:51', '2018-08-09 12:51:30', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(134, 6, 38, 'Dagmadesk', 'dagmadesk', 'nom de la version original', 'synopsis du programme', NULL, NULL, 1, 0, '10x60\'', '2018-07-20', '2018-07-29', '4k', 'cdc475df1203f8c7edfefe5468f8622c.jpeg', 'a1aae46930051871844e0992e65ab18b.jpeg', '8f4418114618904da228f46a7372bc9f.jpeg', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 1, '2018-07-27 13:49:12', '2018-08-09 12:50:57', NULL, 'les recompenses', 'les prix et les nominations', 'l\'audience de ce programme sur divers chaîne de diffusion', NULL, NULL, NULL, NULL, NULL, 'approved'),
(135, 3, 29, 'Baby style\'s', 'baby-styles', 'les stylés de baby', 'Disons que le synopsis est le cerveau de votre scénario. Il va commander le reste du corps afin de se développer. Car le synopsis relate l\'intrigue de votre film contrairement au traitement qui lui va en profondeur dans l\'histoire et relate comment l\'intrigue, la quête et vos personnages évoluent.', NULL, NULL, 1, 0, '10x60\'', '2015-01-09', '2018-07-06', '4k', '2d9797999d8f4ed7203b32d105f4e343.jpeg', 'd51f0069dd9c2392b1240d6998d3bf64.jpeg', 'b75527a02594b25e11d488998ebccf78.jpeg', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 1, '2018-07-28 10:34:04', '2018-08-09 12:50:38', NULL, 'mes recompenses', 'mes nominantions', 'mon audience', NULL, NULL, NULL, NULL, NULL, 'approved'),
(136, 6, 38, 'Adjama bana', 'adjama-bana', 'Adjama bana', 'Disons que le synopsis est le cerveau de votre scénario. Il va commander le reste du corps afin de se développer. Car le synopsis relate l\'intrigue de votre film contrairement au traitement qui lui va en profondeur dans l\'histoire et relate comment l\'intrigue, la quête et vos personnages évoluent', NULL, NULL, 1, 0, '10x60\'', '2003-07-19', '2015-02-09', '4k', '5da13bf596d5ae592fdc83555a8a529f.jpeg', '00216d39061e92c97572d4b0fc6f7a61.jpeg', '62339d70b2d5c91a484edbde6a61dcf2.jpeg', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 1, '2018-07-28 11:02:55', '2018-08-09 12:50:11', NULL, 'mes recompenses', 'mes prix et nominations', 'mes audiences', NULL, NULL, NULL, NULL, NULL, 'approved'),
(137, 9, 38, 'Ijara man', 'ijara-man', 'Joie story', 'Disons que le synopsis est le cerveau de votre scénario. Il va commander le reste du corps afin de se développer. Car le synopsis relate l\'intrigue de votre film contrairement au traitement qui lui va en profondeur dans l\'histoire et relate comment l\'intrigue, la quête et vos personnages évoluent', NULL, NULL, 1, 0, '10x60\'', '2014-06-13', '2018-07-20', '4k', '6c5230c276763be98cd152e9abea4f60.jpeg', '6845211b85def40affa028ea4aba5d4f.jpeg', 'e3be1eca21d379139a1b9a9388e4b026.jpeg', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 'https://vimeo.com/253644176', 1, '2018-07-28 11:50:52', '2018-08-09 12:49:47', NULL, 'Disons que le synopsis est le cerveau de votre scénario. Il va commander le reste du corps afin de se développer. Car le synopsis relate l\'intrigue de votre film contrairement au traitement qui lui va en profondeur dans l\'histoire et relate comment l\'intrigue, la quête et vos personnages évoluent', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'approved'),
(138, 9, 32, 'Adjamata', 'adjamata', 'Djassacité', '### Historique\r\n\r\nUn synopsis est un écrit décrivant la totalité ou un aperçu d\'une œuvre ou d\'une science. Le terme est essentiellement connu pour son usage cinématographique. Dans l\'industrie cinématographique, ce terme désigne le résumé condensé d\'un scénario. À ce titre, il décrit les grandes lignes de l\'histoire, esquisse les principaux personnages et leur évolution, sans entrer dans les détails. Sa longueur peut varier de quelques lignes à plusieurs pages2. De façon générale, il ne comporte pas de dialogues et est rédigé au présent de narration, dans un style simple, souvent indirect. Le synopsis est donc, selon Vincent Pinel, « une première mise en forme de la matière première narrative du film »2. Au début de certains ouvrages, on trouve un synopsis, sur une ou deux pages, qui présente de manière condensée le contenu de chaque chapitre.\r\n\r\n[Globo](http://globo.tv)', 'je le sais', 'quoi d\'autres', 1, 1, '10x60\'', '2018-07-03', '2018-07-13', '4k', '102c3002154e7899e64c467bb301f533.jpeg', '47bd2eeb99ce2e6cb649005142b197b2.jpeg', '3803e187888f75f44ac6347c4a1a1ebc.jpeg', 'https://vimeo.com/205265379', 'https://vimeo.com/253644176/d3cb58d6d5', 'https://vimeo.com/204188760/a8887fabe5', 'https://vimeo.com/204195114/ae7e2d1c0b', 1, '2018-07-28 11:55:26', '2018-08-09 12:49:21', NULL, NULL, 'Disons que le synopsis est le cerveau de votre scénario. Il va commander le reste du corps afin de se développer. Car le synopsis relate l\'intrigue de votre film contrairement au traitement qui lui va en profondeur dans l\'histoire et relate comment l\'intrigue, la quête et vos personnages évoluent', NULL, NULL, NULL, NULL, NULL, NULL, 'approved');
INSERT INTO `movie` (`id`, `category_id`, `language_id`, `name`, `slug`, `original_name`, `synopsis`, `tagline`, `logline`, `in_theather`, `has_exclusivity`, `format`, `year_start`, `year_end`, `mention`, `cover_img`, `landscape_img`, `portrait_img`, `trailer`, `episode_1`, `episode_2`, `episode_3`, `is_published`, `create_at`, `update_at`, `published_at`, `reward`, `award`, `audience`, `insert_mode`, `in_workflow_at`, `desactivated_at`, `rejected_at`, `approved_at`, `state`) VALUES
(152, 4, 34, 'metadata test', 'metadata-test', 'metadata test original', 'Un (ou une) synopsis est un écrit décrivant la totalité ou un aperçu d\'une œuvre ou d\'une science. Le terme est essentiellement connu pour son usage ...', NULL, NULL, 0, 0, '10x45\'', '2018-08-10', NULL, 'HD', NULL, NULL, NULL, 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 0, '2018-08-10 16:00:00', '2018-08-10 17:48:15', NULL, 'mes recompenses', 'mes prix', 'mes audiences', 'meta-webmaster', NULL, NULL, NULL, '2018-08-10 17:47:37', 'pre-moderate'),
(155, 6, 29, 'Rajoilina', 'rajoilina', 'Reagan Mx', 'Un (ou une) synopsis est un écrit décrivant la totalité ou un aperçu d\'une œuvre ou d\'une science. Le terme est essentiellement connu pour son usage ...', NULL, NULL, 0, 0, '23x25\'', '2018-08-10', NULL, '4k', NULL, NULL, NULL, 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 0, '2018-08-10 18:43:17', '2018-08-10 18:43:17', NULL, 'mes recompenses', 'mes prix', 'mes audiences', 'meta-webmaster', NULL, NULL, NULL, NULL, 'pre-moderate'),
(156, 7, 35, 'Bonapate premier', 'bonapate-premier', 'Demajestic', 'Un (ou une) synopsis est un écrit décrivant la totalité ou un aperçu d\'une œuvre ou d\'une science. Le terme est essentiellement connu pour son usage ...', NULL, NULL, 0, 0, '23x25\'', '2018-08-10', NULL, '4k', NULL, NULL, NULL, 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 'http://www.vimeo.com/25698458', 0, '2018-08-10 18:45:26', '2018-08-10 18:46:25', NULL, 'mes recompenses', 'mes prix', 'mes audiences', 'meta-webmaster', NULL, NULL, NULL, '2018-08-10 18:46:25', 'approved');

-- --------------------------------------------------------

--
-- Structure de la table `movie_actor`
--

CREATE TABLE `movie_actor` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `actor_id` int(11) DEFAULT NULL,
  `image_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `movie_actor`
--

INSERT INTO `movie_actor` (`id`, `movie_id`, `actor_id`, `image_id`, `create_at`) VALUES
(1, 133, 53, NULL, '2018-07-04 00:00:00'),
(2, 133, 121, NULL, '2018-07-04 00:00:00'),
(3, 133, 41, NULL, '2018-07-04 00:00:00'),
(4, 133, 130, NULL, '2018-07-04 00:00:00'),
(5, 134, 422, NULL, '2018-07-27 13:49:12'),
(6, 134, 441, NULL, '2018-07-27 13:49:12'),
(7, 134, 425, NULL, '2018-07-27 13:49:12'),
(8, 135, 93, NULL, '2018-07-28 10:34:04'),
(9, 135, 10, NULL, '2018-07-28 10:34:04'),
(10, 135, 142, NULL, '2018-07-28 10:34:04'),
(11, 135, 190, NULL, '2018-07-28 10:34:04'),
(12, 135, 191, NULL, '2018-07-28 10:34:04'),
(13, 136, 93, NULL, '2018-07-28 11:02:55'),
(14, 136, 10, NULL, '2018-07-28 11:02:55'),
(15, 136, 150, NULL, '2018-07-28 11:02:55'),
(16, 136, 18, NULL, '2018-07-28 11:02:55'),
(17, 136, 150, NULL, '2018-07-28 11:02:55'),
(18, 136, 221, NULL, '2018-07-28 11:02:55'),
(19, 136, 186, NULL, '2018-07-28 11:02:55'),
(20, 136, 253, NULL, '2018-07-28 11:02:55'),
(21, 136, 418, NULL, '2018-07-28 11:02:55'),
(22, 136, 185, NULL, '2018-07-28 11:02:55'),
(23, 138, 93, NULL, '2018-08-01 12:28:12'),
(24, 138, 462, NULL, '2018-08-01 12:28:12'),
(25, 138, 194, NULL, '2018-08-01 12:28:12'),
(26, 138, 404, NULL, '2018-08-01 12:28:12'),
(27, 138, 120, NULL, '2018-08-01 12:28:12'),
(28, 138, 20, NULL, '2018-08-01 12:28:12');

-- --------------------------------------------------------

--
-- Structure de la table `movie_country`
--

CREATE TABLE `movie_country` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='on enregistre les pays de production du movie';

--
-- Contenu de la table `movie_country`
--

INSERT INTO `movie_country` (`id`, `movie_id`, `country_id`, `create_at`) VALUES
(1, 134, 6252001, '2018-07-27 13:49:12'),
(2, 134, 2802361, '2018-07-27 13:49:12'),
(3, 135, 2589581, '2018-07-28 10:34:04'),
(4, 135, 2287781, '2018-07-28 10:34:04'),
(5, 136, 2287781, '2018-07-28 11:02:55'),
(6, 136, 1168579, '2018-07-28 11:02:55'),
(7, 137, 2287781, '2018-07-28 11:50:52'),
(9, 138, 3017382, '2018-08-01 12:28:12'),
(10, 138, 2287781, '2018-08-01 12:28:12');

-- --------------------------------------------------------

--
-- Structure de la table `movie_director`
--

CREATE TABLE `movie_director` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `director_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `movie_director`
--

INSERT INTO `movie_director` (`id`, `movie_id`, `director_id`, `create_at`) VALUES
(1, 134, 155, '2018-07-27 13:49:12'),
(2, 134, 166, '2018-07-27 13:49:12'),
(3, 134, 155, '2018-07-27 13:49:12'),
(4, 135, 195, '2018-07-28 10:34:04'),
(5, 135, 143, '2018-07-28 10:34:04'),
(6, 136, 154, '2018-07-28 11:02:55'),
(7, 136, 169, '2018-07-28 11:02:55'),
(8, 137, 142, '2018-07-28 11:50:52'),
(9, 137, 169, '2018-07-28 11:50:52'),
(10, 137, 137, '2018-07-28 11:50:52'),
(15, 138, 158, '2018-08-01 12:29:09'),
(16, 138, 154, '2018-08-01 12:29:09');

-- --------------------------------------------------------

--
-- Structure de la table `movie_episode`
--

CREATE TABLE `movie_episode` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `title` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pos` int(11) NOT NULL COMMENT 'le numéro de l''épisode du movie',
  `full_url` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'l''url d''accès à la video',
  `code_url` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `movie_genre`
--

CREATE TABLE `movie_genre` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `genre_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='table de liaison entre un movie et ses genres';

--
-- Contenu de la table `movie_genre`
--

INSERT INTO `movie_genre` (`id`, `movie_id`, `genre_id`, `create_at`) VALUES
(1, 133, 1, '2018-07-04 00:00:00'),
(2, 133, 2, '2018-07-04 00:00:00'),
(3, 121, 1, '2018-07-05 00:00:00'),
(4, 117, 1, '2018-07-05 00:00:00'),
(5, 134, 1, '2018-07-27 13:49:12'),
(6, 134, 2, '2018-07-27 13:49:12'),
(7, 135, 1, '2018-07-28 10:34:04'),
(8, 135, 2, '2018-07-28 10:34:04'),
(9, 136, 1, '2018-07-28 11:02:55'),
(10, 136, 2, '2018-07-28 11:02:55'),
(11, 137, 2, '2018-07-28 11:50:52'),
(13, 138, 1, '2018-08-01 12:28:12'),
(14, 138, 2, '2018-08-01 12:28:12');

-- --------------------------------------------------------

--
-- Structure de la table `movie_language`
--

CREATE TABLE `movie_language` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `language_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='enregistre les differentes langues disponible d''un movie';

--
-- Contenu de la table `movie_language`
--

INSERT INTO `movie_language` (`id`, `movie_id`, `language_id`, `create_at`) VALUES
(1, 133, 1, '2018-07-04 00:00:00'),
(2, 133, 2, '2018-07-04 00:00:00'),
(3, 134, 2, '2018-07-27 13:49:12'),
(4, 134, 1, '2018-07-27 13:49:12'),
(5, 135, 2, '2018-07-28 10:34:04'),
(6, 135, 1, '2018-07-28 10:34:04'),
(7, 136, 2, '2018-07-28 11:02:55'),
(8, 136, 1, '2018-07-28 11:02:55'),
(9, 137, 1, '2018-07-28 11:50:52'),
(12, 138, 2, '2018-08-01 12:28:12'),
(13, 138, 1, '2018-08-01 12:28:12');

-- --------------------------------------------------------

--
-- Structure de la table `movie_producer`
--

CREATE TABLE `movie_producer` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `producer_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `movie_producer`
--

INSERT INTO `movie_producer` (`id`, `movie_id`, `producer_id`, `create_at`) VALUES
(1, 134, 1, '2018-07-27 13:49:12'),
(2, 135, 1, '2018-07-28 10:34:04'),
(3, 136, 1, '2018-07-28 11:02:55'),
(4, 137, 1, '2018-07-28 11:50:52'),
(6, 138, 1, '2018-08-01 12:28:12');

-- --------------------------------------------------------

--
-- Structure de la table `movie_resource`
--

CREATE TABLE `movie_resource` (
  `id` int(11) NOT NULL,
  `cover` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'stock l''image de couverture du programme',
  `landscape` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'stock la vignette en paysage du programme',
  `portrait` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'stock la vignette en portrait du programme',
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='enregistre les differents formats d''images pour un movie';

-- --------------------------------------------------------

--
-- Structure de la table `movie_reward`
--

CREATE TABLE `movie_reward` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `type` enum('reward','award','nomination') COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `movie_scene`
--

CREATE TABLE `movie_scene` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='enregistre les scenes ou photo du tournage';

--
-- Contenu de la table `movie_scene`
--

INSERT INTO `movie_scene` (`id`, `movie_id`, `image`, `create_at`) VALUES
(1, 138, '4bac433fa7dd1cf99999aa37ce91de84.jpeg', '2018-07-31 15:23:15'),
(2, 138, '97ad083ebe9c25e00bfbef36ee3bcefc.jpeg', '2018-07-31 15:23:20'),
(3, 138, '9c4601b1edd180bfd81880835c97d224.jpeg', '2018-07-31 15:23:26'),
(4, 138, 'c24b2d81f824e7d9a4afcea36078f428.jpeg', '2018-07-31 15:23:28'),
(5, 138, '0aaf6c3a6500b7ef5e9151f00047eafe.jpeg', '2018-07-31 15:23:31'),
(6, 138, 'a06ac7ea4f4298fc35a97ba44a472c99.jpeg', '2018-07-31 15:23:33'),
(7, 138, 'fd200699ed52bca71063f99c1d1fcdea.jpeg', '2018-07-31 15:23:35'),
(8, 138, 'd6cc83c7fbd23917a744195466593144.jpeg', '2018-07-31 15:23:39'),
(9, 138, '7d434ea5be688fd553ada0c038502388.jpeg', '2018-07-31 15:23:46'),
(10, 138, '84303d7d5df88512d662a4efc6aebc9a.jpeg', '2018-07-31 15:23:49'),
(11, 138, '67fbb85165f325f477ccd876aa63e6a3.jpeg', '2018-07-31 15:23:51'),
(12, 138, 'a5230d847b0be4e398595f7a11b4456d.jpeg', '2018-07-31 15:23:53'),
(13, 137, 'd8d1b99ff1a7be7661d45cf2443216ec.jpeg', '2018-07-31 17:08:12'),
(14, 137, 'ab2a5c1b1c9abdf08e0a065ef2787763.jpeg', '2018-07-31 17:08:16'),
(15, 137, 'ffd9d602088264e5f37451fdf0774060.jpeg', '2018-07-31 17:08:27'),
(16, 137, '49a6d6bead82519c5358636322179da1.jpeg', '2018-07-31 17:08:33'),
(17, 137, '2e2175bf0bd10fd3a333b01710a605fc.jpeg', '2018-07-31 17:08:35'),
(18, 131, '88f4f12c483c4c20838c703eb358eac2.jpeg', '2018-08-03 16:48:28');

-- --------------------------------------------------------

--
-- Structure de la table `movie_season`
--

CREATE TABLE `movie_season` (
  `id` int(11) NOT NULL,
  `movie_id` int(11) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le nom ou le titre de la saison',
  `num` int(11) NOT NULL COMMENT 'le numéro de la saison',
  `create_at` datetime NOT NULL COMMENT 'la date à laquelle la saison est ajoutéa à la plateforme'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `movie_trailer`
--

CREATE TABLE `movie_trailer` (
  `id` int(11) NOT NULL,
  `title` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'enregistre le titre ou du trailer',
  `slug` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `full_url` varchar(254) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'url absolue du trailer',
  `code_url` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'code (id) de la video sur vimeo ou youtube',
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` datetime NOT NULL COMMENT 'date d''ajout du trailer sur la plateforme'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `movie_trailer`
--

INSERT INTO `movie_trailer` (`id`, `title`, `slug`, `full_url`, `code_url`, `image`, `create_at`) VALUES
(177, 'Hospital iT', 'hospital-it', 'https://vimeo.com/205265379', NULL, '9479ca0b002e7256d541507330118818.jpeg', '2018-07-24 16:31:16');

-- --------------------------------------------------------

--
-- Structure de la table `original_language`
--

CREATE TABLE `original_language` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `movie_nbr` int(11) NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `original_language`
--

INSERT INTO `original_language` (`id`, `name`, `slug`, `movie_nbr`, `create_at`) VALUES
(27, 'Français', 'francais', 0, '2018-08-09 12:14:21'),
(28, 'Anglais', 'anglais', 0, '2018-08-09 12:14:21'),
(29, 'Portugais', 'portugais', 0, '2018-08-09 12:14:21'),
(30, 'Arabe', 'arabe', 0, '2018-08-09 12:14:21'),
(31, 'Turc', 'turc', 0, '2018-08-09 12:14:21'),
(32, 'Haoussa', 'haoussa', 0, '2018-08-09 12:14:21'),
(33, 'Bambara', 'bambara', 0, '2018-08-09 12:14:21'),
(34, 'Swahili', 'swahili', 0, '2018-08-09 12:14:21'),
(35, 'Lingala', 'lingala', 0, '2018-08-09 12:14:21'),
(36, 'Moré', 'more', 0, '2018-08-09 12:14:21'),
(37, 'Afrikaner', 'afrikaner', 0, '2018-08-09 12:14:21'),
(38, 'Indi', 'indi', 0, '2018-08-09 12:14:21'),
(39, 'Autre', 'autre', 0, '2018-08-09 12:14:21');

-- --------------------------------------------------------

--
-- Structure de la table `producer`
--

CREATE TABLE `producer` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` datetime NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `image` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `movie_nbr` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='cette table enregistre les producteurs de contenus';

--
-- Contenu de la table `producer`
--

INSERT INTO `producer` (`id`, `name`, `slug`, `create_at`, `description`, `image`, `movie_nbr`) VALUES
(1, 'cote ouest audiovisuel', 'cote-ouest-audiovisuel', '2018-07-10 00:00:00', NULL, NULL, 5),
(114, 'MARVISTA', 'marvista', '2018-07-10 00:00:00', NULL, NULL, 0),
(115, 'ABS-CBNCORPORATION', 'abs-cbn-corporation', '2018-07-10 00:00:00', NULL, NULL, 0),
(116, 'AWOL', 'awol', '2018-07-10 00:00:00', NULL, NULL, 0),
(117, 'AWOL ANIMATION', 'awol-animation', '2018-07-10 00:00:00', NULL, NULL, 0),
(118, 'CALIFORNIA PICTURES', 'california-pictures', '2018-07-10 00:00:00', NULL, NULL, 0),
(119, 'Cargo Film & Releasing', 'cargo-film-releasing', '2018-07-10 00:00:00', NULL, NULL, 0),
(120, 'CBS', 'cbs', '2018-07-10 00:00:00', NULL, NULL, 0),
(121, 'CELESTIAL FILMED ENTERTAINMENT LIMITED', 'celestial-filmed-entertainment-limited', '2018-07-10 00:00:00', NULL, NULL, 0),
(122, 'CHAFTOP FILMS', 'chaftop-films', '2018-07-10 00:00:00', NULL, NULL, 0),
(123, 'CHRISTAL SKY', 'christal-sky', '2018-07-10 00:00:00', NULL, NULL, 0),
(124, 'CURB ENTERTAINMENT', 'curb-entertainment', '2018-07-10 00:00:00', NULL, NULL, 0),
(125, 'DISNEY', 'disney', '2018-07-10 00:00:00', NULL, NULL, 0),
(126, 'DOC & FILMS', 'doc-films', '2018-07-10 00:00:00', NULL, NULL, 0),
(127, 'Dori Media', 'dori-media', '2018-07-10 00:00:00', NULL, NULL, 0),
(128, 'ELO FILMS', 'elo-films', '2018-07-10 00:00:00', NULL, NULL, 0),
(129, 'FILM AND PICTURE', 'film-and-picture', '2018-07-10 00:00:00', NULL, NULL, 0),
(130, 'FUTURIKON', 'futurikon', '2018-07-10 00:00:00', NULL, NULL, 0),
(131, 'GALA GOBAL', 'gala-gobal', '2018-07-10 00:00:00', NULL, NULL, 0),
(132, 'GAUMONT', 'gaumont', '2018-07-10 00:00:00', NULL, NULL, 0),
(133, 'GLOBAL TELIF HAKLARI', 'global-telif-haklari', '2018-07-10 00:00:00', NULL, NULL, 0),
(134, 'GLOBO', 'globo', '2018-07-10 00:00:00', NULL, NULL, 0),
(135, 'GLOBO TV', 'globo-tv', '2018-07-10 00:00:00', NULL, NULL, 0),
(136, 'GMA NETWORK', 'gma-network', '2018-07-10 00:00:00', NULL, NULL, 0),
(137, 'GRAVITAS VENTURES', 'gravitas-ventures', '2018-07-10 00:00:00', NULL, NULL, 0),
(138, 'INDIGO', 'indigo', '2018-07-10 00:00:00', NULL, NULL, 0),
(139, 'ITN', 'itn', '2018-07-10 00:00:00', NULL, NULL, 0),
(140, 'ITN DISTRIBUTION', 'itn-distribution', '2018-07-10 00:00:00', NULL, NULL, 0),
(141, 'Lesly Hammond', 'lesly-hammond', '2018-07-10 00:00:00', NULL, NULL, 0),
(142, 'MAINSAIL', 'mainsail', '2018-07-10 00:00:00', NULL, NULL, 0),
(143, 'MAR VISTA', 'mar-vista', '2018-07-10 00:00:00', NULL, NULL, 0),
(144, 'MARCO POLO', 'marco-polo', '2018-07-10 00:00:00', NULL, NULL, 0),
(145, 'PARAMAX', 'paramax', '2018-07-10 00:00:00', NULL, NULL, 0),
(146, 'PICTURE TREE INTERNATIONAL GmnH', 'picture-tree-international-gmnh', '2018-07-10 00:00:00', NULL, NULL, 0),
(147, 'POWER COMPANY LIMITED', 'power-company-limited', '2018-07-10 00:00:00', NULL, NULL, 0),
(148, 'PYRAMID', 'pyramid', '2018-07-10 00:00:00', NULL, NULL, 0),
(149, 'RCTV INTERNATIONAL', 'rctv-international', '2018-07-10 00:00:00', NULL, NULL, 0),
(150, 'SCORPION TV', 'scorpion-tv', '2018-07-10 00:00:00', NULL, NULL, 0),
(151, 'SCREEN MEDIA VENTURES', 'screen-media-ventures', '2018-07-10 00:00:00', NULL, NULL, 0),
(152, 'SIC- SOCIEDADE INDEPENDENTE DE COMMUNICACAO', 'sic-sociedade-independente-de-communicacao', '2018-07-10 00:00:00', NULL, NULL, 0),
(153, 'SPECTRUM VISUAL NETWORK SOLUTION', 'spectrum-visual-network-solution', '2018-07-10 00:00:00', NULL, NULL, 0),
(154, 'SPOTLIGHT PICTURES', 'spotlight-pictures', '2018-07-10 00:00:00', NULL, NULL, 0),
(155, 'SWITCH', 'switch', '2018-07-10 00:00:00', NULL, NULL, 0),
(156, 'TAYEKENI PROD', 'tayekeni-prod', '2018-07-10 00:00:00', NULL, NULL, 0),
(157, 'Team Tarbaby', 'team-tarbaby', '2018-07-10 00:00:00', NULL, NULL, 0),
(158, 'TELEMUNDO', 'telemundo', '2018-07-10 00:00:00', NULL, NULL, 0),
(159, 'TOMCAT FILMS LLC', 'tomcat-films-llc', '2018-07-10 00:00:00', NULL, NULL, 0),
(160, 'TRANS TALES ENTERTAINMENT', 'trans-tales-entertainment', '2018-07-10 00:00:00', NULL, NULL, 0),
(161, 'TRT – TURKISH RADION & TELEVISION CORPORATION', 'trt-turkish-radion-television-corporation', '2018-07-10 00:00:00', NULL, NULL, 0),
(162, 'Uhuru Productions', 'uhuru-productions', '2018-07-10 00:00:00', NULL, NULL, 0),
(163, 'UPSIDE', 'upside', '2018-07-10 00:00:00', NULL, NULL, 0),
(164, 'WILD BUNCH', 'wild-bunch', '2018-07-10 00:00:00', NULL, NULL, 0),
(165, 'YOUNG RICH TELEVISION LTD', 'young-rich-television-ltd', '2018-07-10 00:00:00', NULL, NULL, 0),
(166, 'ZEE TV', 'zee-tv', '2018-07-10 00:00:00', NULL, NULL, 0),
(167, 'Jenny Walsh', 'jenny-walsh', '2018-07-10 00:00:00', NULL, NULL, 0),
(168, 'Roger Savage', 'roger-savage', '2018-07-10 00:00:00', NULL, NULL, 0),
(169, 'Geng Ling', 'geng-ling', '2018-07-10 00:00:00', NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Structure de la table `producer_country`
--

CREATE TABLE `producer_country` (
  `id` int(11) NOT NULL,
  `producer_id` int(11) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='liaison entre les producteurs et leur pays d''origine';

-- --------------------------------------------------------

--
-- Structure de la table `role`
--

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le nom court du role ex: Traducteur',
  `label` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'le label reference du role ex: ROLE_TRANSLATOR',
  `type` enum('role','privilege') COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` varchar(250) COLLATE utf8_unicode_ci NOT NULL COMMENT 'courte description de ce a quoi sert ce role',
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Definition de tout les roles et privileges';

--
-- Contenu de la table `role`
--

INSERT INTO `role` (`id`, `name`, `label`, `type`, `description`, `create_at`) VALUES
(1, 'commerciale', 'ROLE_SALER', 'role', 'permet aux commerciaux de faire le suivi de leurs clients', '2018-07-14 00:00:00'),
(2, 'super administrateur', 'ROLE_SUPER_ADMIN', 'role', 'permet de gerer integralement la plateforme', '2018-07-14 00:00:00'),
(3, 'administrateur', 'ROLE_ADMIN', 'role', 'en dessous du super administrateur ce trouve l\'administrateur', '2018-07-14 00:00:00'),
(4, 'traducteur', 'ROLE_TRANSLATOR', 'privilege', 'permet a un individu de faire la traduction sur la plateforme', '2018-07-14 00:00:00'),
(5, 'catalogue', 'ROLE_CATALOG', 'role', 'gère tout ce qui est  entrée, sortie,  mise à jour des programmes', '2018-07-14 12:28:27'),
(6, 'abonné', 'ROLE_SUBSCRIBER', 'role', 'désigne toute personne qui possède un compte client sur la plateforme.', '2018-07-14 12:34:08'),
(7, 'producteur', 'ROLE_PRODUCER', 'role', 'concerne les compte marqué comme étant des producteurs', '2018-07-14 12:36:04'),
(8, 'réalisateur', 'ROLE_DIRECTOR', 'role', 'concerne les comptes marqué comme étant des réalisateurs', '2018-07-14 12:37:10'),
(9, 'acteur', 'ROLE_ACTOR', 'role', 'concerne les compte marqué comme étant des acteurs', '2018-07-14 12:38:03'),
(10, 'insert d\'utilisateur', 'ROLE_USER_INSERT', 'privilege', 'permet d\'ajouter un nouvel utilisateur sur la plateforme', '2018-07-14 12:40:21'),
(11, 'insertion de programme', 'ROLE_CATALOG_INSERT', 'privilege', 'permet d\'ajouter un nouveau  programme sur la plateforme', '2018-07-14 12:42:07'),
(12, 'suppression de programme', 'ROLE_CATALOG_REMOVE', 'privilege', 'permet de supprimer un programme du catalogue .', '2018-07-14 12:43:32'),
(13, 'mise à jour de programme', 'ROLE_CATALOG_UPDATE', 'privilege', 'permet de mettre à jour un programme du catalogue.', '2018-07-14 12:44:28'),
(14, 'Observateur', 'ROLE_OBSERVER', 'privilege', 'donne la possibilité à une personne de tout voir dans le backend sans pourvoir y apporter des modifications.', '2018-07-30 12:13:37'),
(15, 'Statut De Programme', 'ROLE_PROGRAM_STATUT', 'privilege', 'permet d\'octroyer à une personne la capacité de changer le statut d\'un programme. soit "Publié" ou "Pré-moderation"', '2018-07-30 12:14:29');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `about_me` longtext COLLATE utf8_unicode_ci,
  `salt` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(70) COLLATE utf8_unicode_ci NOT NULL,
  `signup_token` varchar(64) CHARACTER SET utf8 DEFAULT NULL COMMENT 'un code arbitraire généré pour l''activation du compte',
  `create_at` datetime DEFAULT NULL,
  `state` enum('activate','pending','blocked') COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `about_me`, `salt`, `password`, `signup_token`, `create_at`, `state`) VALUES
(518, 'zakeszako', 'zakeszako@test.coa', 'La Bible est un ensemble de textes considérés comme sacrés chez les juifs et les chrétiens. Les différents groupes religieux peuvent inclure différents livres dans leurs canons, dans un ordre différent', NULL, '$2y$13$9a6SnG7cohkWa4Sdm9WRiOjlBf.dVzx2xVofMWYQVrQ1D5RVzFPU2', NULL, '2018-07-19 10:00:38', 'activate'),
(519, 'user05b506146a7379', 'user05b506146a7379@test.coa', NULL, NULL, '$2y$13$9DWuzdQPGOUeRfgIw4/QvuvFzsSZNNzUsAySNt9v/JvBCtO26MsMy', NULL, '2018-07-19 10:00:39', 'activate'),
(520, 'user15b5061473a148', 'user15b5061473a148@test.coa', NULL, NULL, '$2y$13$uFYkdO1RkSdp2lpcU2Vny.oX18CbVlM1GIWCPBnUPepl7rdYFai3K', NULL, '2018-07-19 10:00:39', 'activate'),
(521, 'user25b506147c0ce2', 'user25b506147c0ce2@test.coa', NULL, NULL, '$2y$13$SiIqpdbrsu4rn1zA90exg.tFu0.jYH.85qSF9vgbznABHBOsRUwvC', NULL, '2018-07-19 10:00:40', 'activate'),
(522, 'user35b50614853798', 'user35b50614853798@test.coa', NULL, NULL, '$2y$13$SMhUvPQbQs3yUclmT2k/8erJj.E7Z.BEOhLoiJHLZGLEjLbs4eWNC', NULL, '2018-07-19 10:00:40', 'activate'),
(523, 'user45b506148da56d', 'user45b506148da56d@test.coa', NULL, NULL, '$2y$13$bhcuObIOOyR5aETeRC7ghOXShE1gmmlYMuC8mGmACKussQOqK.QIC', NULL, '2018-07-19 10:00:41', 'activate'),
(524, 'user55b5061496e6f6', 'user55b5061496e6f6@test.coa', NULL, NULL, '$2y$13$rCXHzLjaBjpGBTFaCQEK4uUTi7WQ/T35AbAocwpthalMlbLG3dV1a', NULL, '2018-07-19 10:00:42', 'activate'),
(525, 'user65b50614a01490', 'user65b50614a01490@test.coa', NULL, NULL, '$2y$13$I1Gng2R1gA7dFsAIZmFak.Y/Kexcfuh6AmbMPd9H1MMUyoeDXch0m', NULL, '2018-07-19 10:00:42', 'activate'),
(526, 'user75b50614a88501', 'user75b50614a88501@test.coa', NULL, NULL, '$2y$13$pKtsNudWHB7N4LznPAKI6uq1lYgABflQ2qJ08sM1fbxJfasWuLBea', NULL, '2018-07-19 10:00:43', 'activate'),
(527, 'user85b50614b1b38b', 'user85b50614b1b38b@test.coa', NULL, NULL, '$2y$13$n5JeFQk0k0a5Dx1S8rD11ODs/9BtL4HVD4HB.h840q.GxQXR1PMPG', NULL, '2018-07-19 10:00:43', 'activate'),
(528, 'user95b50614ba2013', 'user95b50614ba2013@test.coa', NULL, NULL, '$2y$13$DdHzmu8cSBeMi5RR8OpWMek6cSg0twJkjaGcbPppVD9zy88nVZ3Pu', NULL, '2018-07-19 10:00:44', 'activate'),
(529, 'user105b50614c34e92', 'user105b50614c34e92@test.coa', NULL, NULL, '$2y$13$YkmTcmboZA6CSPTQSSC4Q.nnWZDux7Lig00qp.WIgXP6mJelKTTX2', NULL, '2018-07-19 10:00:44', 'activate'),
(530, 'user115b50614cbb93f', 'user115b50614cbb93f@test.coa', NULL, NULL, '$2y$13$WBZqOUOF.vHNFLt1hgHbdOLxP5aTEwK6vZoBsrvANcz8Zaizpj5Ei', NULL, '2018-07-19 10:00:45', 'activate'),
(531, 'user125b50614d50042', 'user125b50614d50042@test.coa', NULL, NULL, '$2y$13$aj0zvDlBFFGXUTGV4f/9muTaKD1Fg5YKTjzC5Pd/OF9vEU5i6fKMe', NULL, '2018-07-19 10:00:45', 'activate'),
(532, 'user135b50614dd6f8c', 'user135b50614dd6f8c@test.coa', NULL, NULL, '$2y$13$wjkiw.VIj6Fr3NMrkk7r3umjiLE1bcxQgXMvH7zFM1iEWIy3YTPiW', NULL, '2018-07-19 10:00:46', 'activate'),
(533, 'user145b50614e69a69', 'user145b50614e69a69@test.coa', NULL, NULL, '$2y$13$u/rqXE96XUYayFcsf3GsmepRKckQdL3J43apTMcKs5G8ReGHK2AhO', NULL, '2018-07-19 10:00:46', 'activate'),
(534, 'user155b50614ef0ac4', 'user155b50614ef0ac4@test.coa', NULL, NULL, '$2y$13$GnPueVjCxjuu0Y.1yQX9k.DIwFFq8IYMv8PMyHM/rA4kbJ5TA5QUm', NULL, '2018-07-19 10:00:47', 'activate'),
(535, 'user165b50614f83233', 'user165b50614f83233@test.coa', NULL, NULL, '$2y$13$INLm9CxD2pCSZn1f1/Ih8.UBUHqeumh9EIXyVG88cG2sb1zuZ.67y', NULL, '2018-07-19 10:00:48', 'activate'),
(536, 'user175b50615015cfa', 'user175b50615015cfa@test.coa', NULL, NULL, '$2y$13$kSayq4Q4WoiwVOMNYFBDzu/70iTjcwPCtxLwtvqjCktWel00g1LIq', NULL, '2018-07-19 10:00:48', 'activate'),
(537, 'user185b5061509cd2b', 'user185b5061509cd2b@test.coa', NULL, NULL, '$2y$13$pJyOO30uf4IMLzqqXTgmIuzYiMACuawbMmt08EwWmdlqOYybyaL1q', NULL, '2018-07-19 10:00:49', 'activate'),
(538, 'user195b5061512f928', 'user195b5061512f928@test.coa', NULL, NULL, '$2y$13$5ScVtLkZJH62KWnb3scNk.G1IIIdJraoUJbm.dQSKnOffoZJUO8yK', NULL, '2018-07-19 10:00:49', 'activate'),
(539, 'user205b506151b6d46', 'user205b506151b6d46@test.coa', NULL, NULL, '$2y$13$4COFRmbruenl4gsEkx0O8.uSeMM/wzWV8yCjm8DgpUeqVdkl2qYb.', NULL, '2018-07-19 10:00:50', 'activate'),
(540, 'user215b50615249597', 'user215b50615249597@test.coa', NULL, NULL, '$2y$13$5Ai0tDGF5XaWo7lWPHVxBuxzEBF.P.w62R8L.p9qXPNbMthph/ieC', NULL, '2018-07-19 10:00:50', 'activate'),
(541, 'user225b506152d01ae', 'user225b506152d01ae@test.coa', NULL, NULL, '$2y$13$0svQSbytw7V3ko9o0s8YuOvUAt8v0AVnxOkmq1TpFVESIuXpkST3S', NULL, '2018-07-19 10:00:51', 'activate'),
(542, 'user235b5061536287e', 'user235b5061536287e@test.coa', NULL, NULL, '$2y$13$v6yUUf/NK9F5Y2n1Mh9XS.b6sDsTZetCC3wR284/FJ0a9Q6oZo70a', NULL, '2018-07-19 10:00:51', 'activate'),
(543, 'user245b506153e9762', 'user245b506153e9762@test.coa', NULL, NULL, '$2y$13$sTbnf/RYjZaN1ETbI5SOVeRTc2DtEWrw3dMLB/LFqHKZI5n9po5aS', NULL, '2018-07-19 10:00:52', 'activate'),
(545, 'Albel Kouadio', 'zakeszako@gmail.com', NULL, NULL, '$2y$13$hBexSqaaf0K9i2mJuThskO9yBO0lDcr1/tJVc9NSnm23dzmSCGCxi', 'ZDdkNDNkMDJjNjBhZDg1NTc5YThiNTE4ZjdjN2VjZTdhYmZiNTQxYmIzYWEzNjM2', '2018-07-19 10:00:52', 'pending');

-- --------------------------------------------------------

--
-- Structure de la table `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `user_role`
--

INSERT INTO `user_role` (`id`, `user_id`, `role_id`, `create_at`) VALUES
(82, 518, 2, '2018-07-19 10:00:38'),
(83, 519, 6, '2018-07-19 10:00:39'),
(84, 520, 3, '2018-07-19 10:00:39'),
(85, 521, 6, '2018-07-19 10:00:40'),
(86, 522, 5, '2018-07-19 10:00:40'),
(87, 523, 6, '2018-07-19 10:00:41'),
(88, 524, 9, '2018-07-19 10:00:42'),
(89, 525, 5, '2018-07-19 10:00:42'),
(90, 526, 3, '2018-07-19 10:00:43'),
(91, 527, 9, '2018-07-19 10:00:43'),
(92, 528, 3, '2018-07-19 10:00:44'),
(93, 529, 5, '2018-07-19 10:00:44'),
(94, 530, 7, '2018-07-19 10:00:45'),
(95, 531, 8, '2018-07-19 10:00:45'),
(96, 532, 7, '2018-07-19 10:00:46'),
(97, 533, 9, '2018-07-19 10:00:46'),
(98, 534, 9, '2018-07-19 10:00:47'),
(99, 535, 6, '2018-07-19 10:00:48'),
(100, 536, 3, '2018-07-19 10:00:48'),
(101, 537, 8, '2018-07-19 10:00:49'),
(102, 538, 8, '2018-07-19 10:00:49'),
(103, 539, 7, '2018-07-19 10:00:50'),
(104, 540, 6, '2018-07-19 10:00:50'),
(105, 541, 9, '2018-07-19 10:00:51'),
(106, 542, 7, '2018-07-19 10:00:51'),
(107, 543, 3, '2018-07-19 10:00:52'),
(110, 545, 5, '2018-07-19 10:04:14');

-- --------------------------------------------------------

--
-- Structure de la table `website_mail`
--

CREATE TABLE `website_mail` (
  `id` int(11) NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  `referer_id` int(11) DEFAULT NULL,
  `firstname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(254) COLLATE utf8_unicode_ci NOT NULL,
  `subject` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `message` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `referer_message` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `create_at` datetime NOT NULL,
  `is_processed` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `website_mail`
--

INSERT INTO `website_mail` (`id`, `department_id`, `referer_id`, `firstname`, `lastname`, `email`, `subject`, `message`, `referer_message`, `create_at`, `is_processed`) VALUES
(2, 2, 10, 'zacharie aké', 'assagou', 'zakeszako@yahoo.fr', 'Test de formulaire contact', 'bsdfbs bkfkbs b dbskgns mgnbsgb sd', NULL, '2018-07-11 18:22:25', 0),
(6, 2, 10, 'zacharie aké', 'assagou', 'zakeszako@yahoo.fr', 'Test de formulaire contact', 'bgbgbsgbj sgbsgbns', 'ok xa marche', '2018-07-11 18:27:42', 0),
(7, 2, 10, 'zacharie aké', 'assagou', 'zakeszako@yahoo.fr', 'Test de formulaire contact', 'rgezetgzget', 'moi koi', '2018-07-11 18:32:02', 0),
(8, 2, 10, 'zacharie aké', 'assagou', 'zakeszako@yahoo.fr', 'Test de formulaire contact', 'v vcvhkhc dc kvhdcD', 'ok xa marche', '2018-07-11 18:35:33', 0);

-- --------------------------------------------------------

--
-- Structure de la table `website_referer`
--

CREATE TABLE `website_referer` (
  `id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `create_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `website_referer`
--

INSERT INTO `website_referer` (`id`, `name`, `slug`, `create_at`) VALUES
(6, 'Je connais l’adresse de votre site', 'je-connais-l-adresse-de-votre-site', '2018-07-11 15:40:09'),
(7, 'Recherche sur google', 'recherche-sur-google', '2018-07-11 15:40:09'),
(8, 'Communiqué de presse / article', 'communique-de-presse-article', '2018-07-11 15:40:09'),
(9, 'Newsletter de Côte Ouest', 'newsletter-de-cote-ouest', '2018-07-11 15:40:09'),
(10, 'Autres', 'autres', '2018-07-11 15:40:09');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `actor`
--
ALTER TABLE `actor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_447556F9989D9B62` (`slug`);

--
-- Index pour la table `actor_country`
--
ALTER TABLE `actor_country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_7186990C10DAF24A` (`actor_id`),
  ADD KEY `IDX_7186990CF92F3E70` (`country_id`);

--
-- Index pour la table `catalog`
--
ALTER TABLE `catalog`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_1B2C32475F37A13B` (`token`),
  ADD KEY `IDX_1B2C324761220EA6` (`creator_id`);

--
-- Index pour la table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_64C19C15E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_64C19C1989D9B62` (`slug`);

--
-- Index pour la table `country`
--
ALTER TABLE `country`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_CD1DE18A5E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_CD1DE18A989D9B62` (`slug`);

--
-- Index pour la table `director`
--
ALTER TABLE `director`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_1E90D3F0989D9B62` (`slug`);

--
-- Index pour la table `director_country`
--
ALTER TABLE `director_country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_80CD1A29899FB366` (`director_id`),
  ADD KEY `IDX_80CD1A29F92F3E70` (`country_id`);

--
-- Index pour la table `ext_translations`
--
ALTER TABLE `ext_translations`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `lookup_unique_idx` (`locale`,`object_class`,`field`,`foreign_key`),
  ADD KEY `translations_lookup_idx` (`locale`,`object_class`,`foreign_key`);

--
-- Index pour la table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8C9F36105E237E06` (`name`);

--
-- Index pour la table `genre`
--
ALTER TABLE `genre`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_835033F85E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_835033F8989D9B62` (`slug`);

--
-- Index pour la table `image`
--
ALTER TABLE `image`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_C53D045F93CB796C` (`file_id`);

--
-- Index pour la table `language`
--
ALTER TABLE `language`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_D4DB71B55E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_D4DB71B5989D9B62` (`slug`);

--
-- Index pour la table `metadata`
--
ALTER TABLE `metadata`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_4F1434148C9F3610` (`file`);

--
-- Index pour la table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_1D5EF26F5E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_1D5EF26F989D9B62` (`slug`),
  ADD KEY `IDX_1D5EF26F12469DE2` (`category_id`),
  ADD KEY `IDX_1D5EF26F82F1BAF4` (`language_id`);
ALTER TABLE `movie` ADD FULLTEXT KEY `IDX_1D5EF26F989D9B62572AD4A9` (`slug`,`synopsis`);

--
-- Index pour la table `movie_actor`
--
ALTER TABLE `movie_actor`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_3A374C653DA5256D` (`image_id`),
  ADD KEY `IDX_3A374C658F93B6FC` (`movie_id`),
  ADD KEY `IDX_3A374C6510DAF24A` (`actor_id`);

--
-- Index pour la table `movie_country`
--
ALTER TABLE `movie_country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_73E58B488F93B6FC` (`movie_id`),
  ADD KEY `IDX_73E58B48F92F3E70` (`country_id`);

--
-- Index pour la table `movie_director`
--
ALTER TABLE `movie_director`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_C266487D8F93B6FC` (`movie_id`),
  ADD KEY `IDX_C266487D899FB366` (`director_id`);

--
-- Index pour la table `movie_episode`
--
ALTER TABLE `movie_episode`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FD3C5EF48F93B6FC` (`movie_id`);

--
-- Index pour la table `movie_genre`
--
ALTER TABLE `movie_genre`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_FD1229648F93B6FC` (`movie_id`),
  ADD KEY `IDX_FD1229644296D31F` (`genre_id`);

--
-- Index pour la table `movie_language`
--
ALTER TABLE `movie_language`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_82DEA388F93B6FC` (`movie_id`),
  ADD KEY `IDX_82DEA3882F1BAF4` (`language_id`);

--
-- Index pour la table `movie_producer`
--
ALTER TABLE `movie_producer`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_4B92D2518F93B6FC` (`movie_id`),
  ADD KEY `IDX_4B92D25189B658FE` (`producer_id`);

--
-- Index pour la table `movie_resource`
--
ALTER TABLE `movie_resource`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `movie_reward`
--
ALTER TABLE `movie_reward`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_B716EF268F93B6FC` (`movie_id`);

--
-- Index pour la table `movie_scene`
--
ALTER TABLE `movie_scene`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_A73BF5468F93B6FC` (`movie_id`);

--
-- Index pour la table `movie_season`
--
ALTER TABLE `movie_season`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_923C6DC8F93B6FC` (`movie_id`);

--
-- Index pour la table `movie_trailer`
--
ALTER TABLE `movie_trailer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_E6079E60989D9B62` (`slug`);

--
-- Index pour la table `original_language`
--
ALTER TABLE `original_language`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_F78496A45E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_F78496A4989D9B62` (`slug`);

--
-- Index pour la table `producer`
--
ALTER TABLE `producer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_976449DC989D9B62` (`slug`);

--
-- Index pour la table `producer_country`
--
ALTER TABLE `producer_country`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5759CDAE89B658FE` (`producer_id`),
  ADD KEY `IDX_5759CDAEF92F3E70` (`country_id`);

--
-- Index pour la table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_57698A6A5E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_57698A6AEA750E8` (`label`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`);

--
-- Index pour la table `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_2DE8C6A3A76ED395` (`user_id`),
  ADD KEY `IDX_2DE8C6A3D60322AC` (`role_id`);

--
-- Index pour la table `website_mail`
--
ALTER TABLE `website_mail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `IDX_5323453CAE80F5DF` (`department_id`),
  ADD KEY `IDX_5323453C87C61384` (`referer_id`);

--
-- Index pour la table `website_referer`
--
ALTER TABLE `website_referer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UNIQ_F9F24A215E237E06` (`name`),
  ADD UNIQUE KEY `UNIQ_F9F24A21989D9B62` (`slug`);

--
-- AUTO_INCREMENT pour les tables exportées
--

--
-- AUTO_INCREMENT pour la table `actor`
--
ALTER TABLE `actor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=475;
--
-- AUTO_INCREMENT pour la table `actor_country`
--
ALTER TABLE `actor_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `catalog`
--
ALTER TABLE `catalog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `country`
--
ALTER TABLE `country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7909808;
--
-- AUTO_INCREMENT pour la table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT pour la table `director`
--
ALTER TABLE `director`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=196;
--
-- AUTO_INCREMENT pour la table `director_country`
--
ALTER TABLE `director_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `ext_translations`
--
ALTER TABLE `ext_translations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=125;
--
-- AUTO_INCREMENT pour la table `file`
--
ALTER TABLE `file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `genre`
--
ALTER TABLE `genre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;
--
-- AUTO_INCREMENT pour la table `image`
--
ALTER TABLE `image`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `language`
--
ALTER TABLE `language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `metadata`
--
ALTER TABLE `metadata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=99;
--
-- AUTO_INCREMENT pour la table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=157;
--
-- AUTO_INCREMENT pour la table `movie_actor`
--
ALTER TABLE `movie_actor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
--
-- AUTO_INCREMENT pour la table `movie_country`
--
ALTER TABLE `movie_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT pour la table `movie_director`
--
ALTER TABLE `movie_director`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT pour la table `movie_episode`
--
ALTER TABLE `movie_episode`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `movie_genre`
--
ALTER TABLE `movie_genre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT pour la table `movie_language`
--
ALTER TABLE `movie_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT pour la table `movie_producer`
--
ALTER TABLE `movie_producer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT pour la table `movie_resource`
--
ALTER TABLE `movie_resource`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `movie_reward`
--
ALTER TABLE `movie_reward`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `movie_scene`
--
ALTER TABLE `movie_scene`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT pour la table `movie_season`
--
ALTER TABLE `movie_season`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `movie_trailer`
--
ALTER TABLE `movie_trailer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;
--
-- AUTO_INCREMENT pour la table `original_language`
--
ALTER TABLE `original_language`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;
--
-- AUTO_INCREMENT pour la table `producer`
--
ALTER TABLE `producer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=170;
--
-- AUTO_INCREMENT pour la table `producer_country`
--
ALTER TABLE `producer_country`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT pour la table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=546;
--
-- AUTO_INCREMENT pour la table `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=111;
--
-- AUTO_INCREMENT pour la table `website_mail`
--
ALTER TABLE `website_mail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT pour la table `website_referer`
--
ALTER TABLE `website_referer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `actor_country`
--
ALTER TABLE `actor_country`
  ADD CONSTRAINT `FK_7186990C10DAF24A` FOREIGN KEY (`actor_id`) REFERENCES `actor` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_7186990CF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `catalog`
--
ALTER TABLE `catalog`
  ADD CONSTRAINT `FK_1B2C324761220EA6` FOREIGN KEY (`creator_id`) REFERENCES `user` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `director_country`
--
ALTER TABLE `director_country`
  ADD CONSTRAINT `FK_80CD1A29899FB366` FOREIGN KEY (`director_id`) REFERENCES `director` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_80CD1A29F92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `image`
--
ALTER TABLE `image`
  ADD CONSTRAINT `FK_C53D045F93CB796C` FOREIGN KEY (`file_id`) REFERENCES `file` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie`
--
ALTER TABLE `movie`
  ADD CONSTRAINT `FK_1D5EF26F12469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `FK_1D5EF26F82F1BAF4` FOREIGN KEY (`language_id`) REFERENCES `original_language` (`id`) ON DELETE SET NULL;

--
-- Contraintes pour la table `movie_actor`
--
ALTER TABLE `movie_actor`
  ADD CONSTRAINT `FK_3A374C6510DAF24A` FOREIGN KEY (`actor_id`) REFERENCES `actor` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_3A374C653DA5256D` FOREIGN KEY (`image_id`) REFERENCES `image` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `FK_3A374C658F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_country`
--
ALTER TABLE `movie_country`
  ADD CONSTRAINT `FK_73E58B488F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_73E58B48F92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_director`
--
ALTER TABLE `movie_director`
  ADD CONSTRAINT `FK_C266487D899FB366` FOREIGN KEY (`director_id`) REFERENCES `director` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_C266487D8F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_episode`
--
ALTER TABLE `movie_episode`
  ADD CONSTRAINT `FK_FD3C5EF48F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_genre`
--
ALTER TABLE `movie_genre`
  ADD CONSTRAINT `FK_FD1229644296D31F` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_FD1229648F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_language`
--
ALTER TABLE `movie_language`
  ADD CONSTRAINT `FK_82DEA3882F1BAF4` FOREIGN KEY (`language_id`) REFERENCES `language` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_82DEA388F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_producer`
--
ALTER TABLE `movie_producer`
  ADD CONSTRAINT `FK_4B92D25189B658FE` FOREIGN KEY (`producer_id`) REFERENCES `producer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_4B92D2518F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_reward`
--
ALTER TABLE `movie_reward`
  ADD CONSTRAINT `FK_B716EF268F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_scene`
--
ALTER TABLE `movie_scene`
  ADD CONSTRAINT `FK_A73BF5468F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `movie_season`
--
ALTER TABLE `movie_season`
  ADD CONSTRAINT `FK_923C6DC8F93B6FC` FOREIGN KEY (`movie_id`) REFERENCES `movie` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `producer_country`
--
ALTER TABLE `producer_country`
  ADD CONSTRAINT `FK_5759CDAE89B658FE` FOREIGN KEY (`producer_id`) REFERENCES `producer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_5759CDAEF92F3E70` FOREIGN KEY (`country_id`) REFERENCES `country` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `user_role`
--
ALTER TABLE `user_role`
  ADD CONSTRAINT `FK_2DE8C6A3A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_2DE8C6A3D60322AC` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE;

--
-- Contraintes pour la table `website_mail`
--
ALTER TABLE `website_mail`
  ADD CONSTRAINT `FK_5323453C87C61384` FOREIGN KEY (`referer_id`) REFERENCES `website_referer` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `FK_5323453CAE80F5DF` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`) ON DELETE SET NULL;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
